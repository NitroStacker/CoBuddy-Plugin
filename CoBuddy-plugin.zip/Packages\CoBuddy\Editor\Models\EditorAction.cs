using System;

namespace CoBuddy.Editor.Models
{
    [Serializable]
    public class EditorAction
    {
        public string action;
        public string name;
        public string parent;
        public string target;
        public string path;
        public string prefabPath;
        public string componentType;
        public float[] position;
        // createTag
        public string tag;
        // createPrimitive
        public string primitiveType;
        // reparentGameObject
        public string newParent;
        // updateGameObject
        public float[] rotation;
        public float[] scale;
        // createScriptableObject, createMaterial, createShader
        public string assetPath;
        public string scriptableObjectType;
        public string shaderName;
        public string shaderSource;
        // updateMaterial
        public string materialProperties;
        // setRectTransformLayout
        public float anchorMinX, anchorMinY, anchorMaxX, anchorMaxY;
        public float posX, posY, sizeDeltaX, sizeDeltaY, pivotX, pivotY;
        // printAssets
        public string folder;
        // updateAssetImporter (TextureImporter)
        public int maxTextureSize;
        // updateCanvas
        public string renderMode;
        // updateUIImage, updateUIText - use color array [r,g,b,a] 0-1, or colorR/G/B/A
        public float[] color;
        public float colorR = -1f, colorG = -1f, colorB = -1f, colorA = -1f;
        public string imageType;
        public string spritePath;
        // updateUIText
        public string text;
        public int fontSize;
        public string alignment;
        // createCircleSprite
        public int spriteSize = 128;
    }
}
