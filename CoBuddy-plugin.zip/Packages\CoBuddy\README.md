# CoBuddy Unity Package

CoBuddy by OpenGate - AI Unity assistant. This package runs inside Unity and provides:

- **Project indexing** - Scripts, asmdefs, manifest
- **Bridge server** - HTTP API on port 38472 for the CoBuddy desktop app
- **Patch application** - Apply code changes from the app
- **Status window** - Window > CoBuddy

## Installation

1. Download the CoBuddy desktop app from [cobuddydev.com](https://cobuddydev.com)
2. Launch CoBuddy and select your Unity project
3. Click **Setup CoBuddy** in the app to install this package automatically

The CoBuddy app fetches and installs the Unity package from cobuddydev.com. Manual installation is not required.

## Usage

1. Install the CoBuddy desktop app from [cobuddydev.com](https://cobuddydev.com)
2. Launch the CoBuddy app and select this Unity project
3. Open this Unity project (with CoBuddy package installed)
4. Both will show green when connected

The CoBuddy app handles all AI (Claude) and UI. This package provides project context and executes changes.
