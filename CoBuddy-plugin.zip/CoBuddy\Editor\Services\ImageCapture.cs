using System;
using System.IO;
using UnityEditor;
using UnityEngine;
using UnityEngine.Rendering;

namespace CoBuddy.Editor.Services
{
    /// <summary>
    /// Captures Game View and Scene View screenshots as JPEG images.
    /// All capture methods must run on the main thread.
    /// Returns base64-encoded JPEG data for transport over HTTP/WebSocket.
    /// </summary>
    public static class ImageCapture
    {
        private const int JpegQuality = 85;
        private const int MaxDimension = 1024; // Downscale if larger

        private static readonly string TempDir = Path.Combine(Application.temporaryCachePath, "CoBuddyCaptures");

        /// <summary>
        /// Captures the Game View (what the player sees). Works in both Edit and Play mode.
        /// Returns base64-encoded JPEG string, or null on failure.
        /// </summary>
        public static ScreenshotResult CaptureGameView()
        {
            try
            {
                if (!Directory.Exists(TempDir))
                    Directory.CreateDirectory(TempDir);

                string tempPath = Path.Combine(TempDir, "gameview.png");

                // ScreenCapture writes to disk relative to project root
                string relativePath = GetRelativePath(tempPath);
                ScreenCapture.CaptureScreenshot(relativePath);

                // Force a repaint so the capture actually happens
                UnityEditorInternal.InternalEditorUtility.RepaintAllViews();

                // ScreenCapture is async — we need to wait for the file
                // Return a deferred result that the caller polls for
                return new ScreenshotResult
                {
                    success = false,
                    pendingPath = tempPath,
                    message = "pending"
                };
            }
            catch (Exception ex)
            {
                return new ScreenshotResult { success = false, message = ex.Message };
            }
        }

        /// <summary>
        /// Checks if a pending game view capture is ready. Call this after CaptureGameView().
        /// </summary>
        public static ScreenshotResult CheckPendingCapture(string pendingPath)
        {
            try
            {
                if (!File.Exists(pendingPath))
                    return new ScreenshotResult { success = false, pendingPath = pendingPath, message = "pending" };

                byte[] fileBytes = File.ReadAllBytes(pendingPath);
                try { File.Delete(pendingPath); } catch { }

                var tex = new Texture2D(2, 2);
                if (!tex.LoadImage(fileBytes))
                {
                    UnityEngine.Object.DestroyImmediate(tex);
                    return new ScreenshotResult { success = false, message = "Failed to load captured image" };
                }

                var result = EncodeAndReturn(tex);
                UnityEngine.Object.DestroyImmediate(tex);
                return result;
            }
            catch (Exception ex)
            {
                return new ScreenshotResult { success = false, message = ex.Message };
            }
        }

        /// <summary>
        /// Captures the Scene View (editor camera). Must be called from the main thread.
        /// Returns base64-encoded JPEG immediately (synchronous RenderTexture capture).
        /// </summary>
        public static ScreenshotResult CaptureSceneView()
        {
            try
            {
                var sceneView = SceneView.lastActiveSceneView;
                if (sceneView == null)
                    return new ScreenshotResult { success = false, message = "No active Scene View" };

                var camera = sceneView.camera;
                if (camera == null)
                    return new ScreenshotResult { success = false, message = "Scene View camera not available" };

                // Determine capture size (clamp to MaxDimension)
                int width = Mathf.Min((int)sceneView.position.width, MaxDimension);
                int height = Mathf.Min((int)sceneView.position.height, MaxDimension);
                if (width <= 0 || height <= 0)
                    return new ScreenshotResult { success = false, message = "Scene View has zero size" };

                // Force repaint to ensure camera is up to date
                sceneView.Repaint();

                // Create render texture and capture
                var rt = new RenderTexture(width, height, 24, RenderTextureFormat.ARGB32);
                var previousRT = camera.targetTexture;
                camera.targetTexture = rt;
                camera.Render();
                camera.targetTexture = previousRT;

                // Read pixels from render texture
                var previousActive = RenderTexture.active;
                RenderTexture.active = rt;
                var tex = new Texture2D(width, height, TextureFormat.RGB24, false);
                tex.ReadPixels(new Rect(0, 0, width, height), 0, 0);
                tex.Apply();
                RenderTexture.active = previousActive;

                // Cleanup render texture
                rt.Release();
                UnityEngine.Object.DestroyImmediate(rt);

                var result = EncodeAndReturn(tex);
                UnityEngine.Object.DestroyImmediate(tex);
                return result;
            }
            catch (Exception ex)
            {
                return new ScreenshotResult { success = false, message = ex.Message };
            }
        }

        /// <summary>
        /// Captures a preview image of an asset at the given path.
        /// Works for prefabs, materials, textures, models, etc.
        /// </summary>
        public static ScreenshotResult CaptureAssetPreview(string assetPath)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(assetPath))
                    return new ScreenshotResult { success = false, message = "No asset path provided" };

                var asset = AssetDatabase.LoadAssetAtPath<UnityEngine.Object>(assetPath);
                if (asset == null)
                    return new ScreenshotResult { success = false, message = $"Asset not found: {assetPath}" };

                // Request asset preview (Unity caches these)
                var preview = AssetPreview.GetAssetPreview(asset);
                if (preview == null)
                {
                    // Try mini thumbnail as fallback
                    preview = AssetPreview.GetMiniThumbnail(asset);
                }
                if (preview == null)
                    return new ScreenshotResult { success = false, message = "No preview available for this asset" };

                // AssetPreview textures are read-only, we need to copy to a new texture
                var rt = RenderTexture.GetTemporary(preview.width, preview.height, 0, RenderTextureFormat.ARGB32);
                Graphics.Blit(preview, rt);
                var previousActive = RenderTexture.active;
                RenderTexture.active = rt;
                var tex = new Texture2D(preview.width, preview.height, TextureFormat.RGB24, false);
                tex.ReadPixels(new Rect(0, 0, preview.width, preview.height), 0, 0);
                tex.Apply();
                RenderTexture.active = previousActive;
                RenderTexture.ReleaseTemporary(rt);

                var result = EncodeAndReturn(tex);
                UnityEngine.Object.DestroyImmediate(tex);
                return result;
            }
            catch (Exception ex)
            {
                return new ScreenshotResult { success = false, message = ex.Message };
            }
        }

        /// <summary>
        /// Downscales if needed, encodes to JPEG, returns base64 result.
        /// </summary>
        private static ScreenshotResult EncodeAndReturn(Texture2D tex)
        {
            // Downscale if too large
            if (tex.width > MaxDimension || tex.height > MaxDimension)
            {
                float scale = Mathf.Min((float)MaxDimension / tex.width, (float)MaxDimension / tex.height);
                int newW = Mathf.Max(1, Mathf.RoundToInt(tex.width * scale));
                int newH = Mathf.Max(1, Mathf.RoundToInt(tex.height * scale));

                var rt = RenderTexture.GetTemporary(newW, newH, 0, RenderTextureFormat.ARGB32);
                Graphics.Blit(tex, rt);
                var prev = RenderTexture.active;
                RenderTexture.active = rt;
                var downscaled = new Texture2D(newW, newH, TextureFormat.RGB24, false);
                downscaled.ReadPixels(new Rect(0, 0, newW, newH), 0, 0);
                downscaled.Apply();
                RenderTexture.active = prev;
                RenderTexture.ReleaseTemporary(rt);

                byte[] jpg = ImageConversion.EncodeToJPG(downscaled, JpegQuality);
                int w = downscaled.width, h = downscaled.height;
                UnityEngine.Object.DestroyImmediate(downscaled);

                return new ScreenshotResult
                {
                    success = true,
                    base64 = Convert.ToBase64String(jpg),
                    width = w,
                    height = h,
                    format = "jpeg"
                };
            }
            else
            {
                byte[] jpg = ImageConversion.EncodeToJPG(tex, JpegQuality);
                return new ScreenshotResult
                {
                    success = true,
                    base64 = Convert.ToBase64String(jpg),
                    width = tex.width,
                    height = tex.height,
                    format = "jpeg"
                };
            }
        }

        private static string GetRelativePath(string absolutePath)
        {
            string projectRoot = Path.GetDirectoryName(Application.dataPath);
            if (!string.IsNullOrEmpty(projectRoot) && absolutePath.StartsWith(projectRoot))
            {
                string relative = absolutePath.Substring(projectRoot.Length);
                if (relative.StartsWith(Path.DirectorySeparatorChar.ToString()) || relative.StartsWith("/"))
                    relative = relative.Substring(1);
                return relative.Replace("\\", "/");
            }
            return absolutePath;
        }
    }

    [Serializable]
    public class ScreenshotResult
    {
        public bool success;
        public string base64;
        public int width;
        public int height;
        public string format;
        public string message;
        public string pendingPath; // For async game view capture
    }
}
