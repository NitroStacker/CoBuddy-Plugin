using UnityEditor;
using UnityEngine;

namespace CoBuddy.Editor
{
    /// <summary>
    /// Minimal CoBuddy status window. Full UI lives in the CoBuddy desktop app.
    /// </summary>
    public class CoBuddyWindow : EditorWindow
    {
        [MenuItem("Window/CoBuddy")]
        public static void ShowWindow()
        {
            var window = GetWindow<CoBuddyWindow>("CoBuddy");
            window.minSize = new Vector2(280, 120);
        }

        private void OnGUI()
        {
            GUILayout.Space(12);
            EditorGUILayout.LabelField("CoBuddy by OpenGate", EditorStyles.boldLabel);
            EditorGUILayout.LabelField("Unity AI Assistant", EditorStyles.miniLabel);
            GUILayout.Space(8);

            EditorGUILayout.LabelField("Status", "Bridge running on port 38472");
            EditorGUILayout.LabelField("Project", System.IO.Path.GetFileName(System.IO.Path.GetFullPath(".")) ?? "—");
            GUILayout.Space(8);

            EditorGUILayout.HelpBox(
                "Connect the CoBuddy desktop app to this project. " +
                "Select your Unity project in the app and ensure both are running.",
                MessageType.Info);

            GUILayout.Space(8);
            if (GUILayout.Button("Open CoBuddy Documentation"))
            {
                Application.OpenURL("https://cobuddydev.com/docs/welcome");
            }
        }
    }
}
