# CoBuddy Unity Package

CoBuddy by OpenGate - AI Unity assistant. This package runs inside Unity and provides:

- **Project indexing** - Scripts, asmdefs, manifest
- **Bridge server** - HTTP API on port 38472 for the CoBuddy desktop app
- **Patch application** - Apply code changes from the app
- **Status window** - Window > CoBuddy

## Installation

1. Open your Unity project
2. Window > Package Manager > Add (+) > Add package from git URL
3. Enter: `https://github.com/NitroStacker/CoBuddy.git?path=Packages/CoBuddy`
4. Click Add

Or add to `Packages/manifest.json`:

```json
{
  "dependencies": {
    "com.opengate.cobuddy": "https://github.com/NitroStacker/CoBuddy.git?path=Packages/CoBuddy"
  }
}
```

## Usage

1. Install the CoBuddy desktop app from [GitHub Releases](https://github.com/NitroStacker/CoBuddy/releases). The Unity plugin is distributed via [CoBuddy-Plugin](https://github.com/NitroStacker/CoBuddy-Plugin).
2. Launch the CoBuddy app and select this Unity project
3. Open this Unity project (with CoBuddy package installed)
4. Both will show green when connected

The CoBuddy app handles all AI (Claude) and UI. This package provides project context and executes changes.
