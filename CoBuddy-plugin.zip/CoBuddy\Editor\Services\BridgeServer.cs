using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using UnityEditor;
using UnityEditor.Compilation;
using UnityEngine;
using CoBuddy.Editor.Models;

namespace CoBuddy.Editor.Services
{
    /// <summary>
    /// HTTP bridge server for CoBuddy app. Runs on port 38472.
    /// Receives: /ping, /index, /patches. Executes patch application on main thread.
    /// </summary>
    [InitializeOnLoad]
    public static class BridgeServer
    {
        private const int Port = 38472;
        private static HttpListener _listener;
        private static Thread _thread;
        private static bool _running;
        private static readonly Queue<Action> MainThreadQueue = new Queue<Action>();
        private static readonly object QueueLock = new object();
        private static List<PatchResult> _pendingPatchResults;
        private static ManualResetEvent _patchDoneEvent;
        private static ActionResult[] _pendingActionResults;
        private static ManualResetEvent _actionsDoneEvent;
        private static List<string> _sceneRootsResult;
        private static ManualResetEvent _sceneRootsEvent;
        private static bool _isPlayModeResult;
        private static List<ComponentEntry> _componentsResult;
        private static ManualResetEvent _componentsEvent;
        private static readonly List<List<LastAppliedChange>> _batchStack = new List<List<LastAppliedChange>>();
        private static readonly List<List<ActionRevertRecord>> _actionBatchStack = new List<List<ActionRevertRecord>>();
        private static ManualResetEvent _revertActionsDoneEvent;
        private static List<string> _unusedAssetsResult;
        private static ManualResetEvent _unusedAssetsEvent;

        // Phase 32: Progress and cancel
        private static CancellationTokenSource _currentActionsCts;
        private static volatile bool _operationInProgress;
        private static volatile float _operationProgress;
        private static volatile string _operationStatus;

        static BridgeServer()
        {
            EditorApplication.playModeStateChanged += OnPlayModeStateChanged;
            EditorApplication.update += ProcessMainThreadQueue;
            Start();
        }

        private static void OnPlayModeStateChanged(PlayModeStateChange state)
        {
            if (state == PlayModeStateChange.EnteredEditMode || state == PlayModeStateChange.EnteredPlayMode)
            {
                Start();
            }
        }

        public static void Start()
        {
            if (_running)
                return;

            try
            {
                _listener = new HttpListener();
                _listener.Prefixes.Add($"http://127.0.0.1:{Port}/");
                _listener.Start();
                _running = true;
                _thread = new Thread(ListenLoop) { IsBackground = true };
                _thread.Start();
                Debug.Log($"[CoBuddy] Bridge server started on port {Port}");
            }
            catch (Exception ex)
            {
                Debug.LogWarning($"[CoBuddy] Failed to start bridge: {ex.Message}");
            }
        }

        public static void Stop()
        {
            _running = false;
            try
            {
                _listener?.Stop();
                _listener?.Close();
            }
            catch { }
            _listener = null;
        }

        private static void ListenLoop()
        {
            while (_running && _listener != null)
            {
                try
                {
                    var context = _listener.GetContext();
                    HandleRequest(context);
                }
                catch (HttpListenerException)
                {
                    break;
                }
                catch (Exception ex)
                {
                    Debug.LogWarning($"[CoBuddy] Bridge error: {ex.Message}");
                }
            }
        }

        private static void HandleRequest(HttpListenerContext context)
        {
            string path = context.Request.Url?.AbsolutePath?.TrimEnd('/') ?? "";
            string method = context.Request.HttpMethod ?? "GET";

            try
            {
                if (path.EndsWith("/ping", StringComparison.OrdinalIgnoreCase) && method == "POST")
                {
                    HandlePing(context);
                    return;
                }
                if (path.EndsWith("/index", StringComparison.OrdinalIgnoreCase) && method == "GET")
                {
                    HandleIndex(context);
                    return;
                }
                if (path.EndsWith("/patches", StringComparison.OrdinalIgnoreCase) && method == "POST")
                {
                    HandlePatches(context);
                    return;
                }
                if (path.EndsWith("/revert", StringComparison.OrdinalIgnoreCase) && method == "POST")
                {
                    HandleRevert(context);
                    return;
                }
                if (path.EndsWith("/actions", StringComparison.OrdinalIgnoreCase) && method == "POST")
                {
                    HandleActions(context);
                    return;
                }
                if (path.EndsWith("/actions/status", StringComparison.OrdinalIgnoreCase) && method == "GET")
                {
                    HandleActionsStatus(context);
                    return;
                }
                if (path.EndsWith("/actions/cancel", StringComparison.OrdinalIgnoreCase) && method == "POST")
                {
                    HandleActionsCancel(context);
                    return;
                }
                if (path.EndsWith("/revert-actions", StringComparison.OrdinalIgnoreCase) && method == "POST")
                {
                    HandleRevertActions(context);
                    return;
                }
                if (path.EndsWith("/compile-status", StringComparison.OrdinalIgnoreCase) && method == "GET")
                {
                    HandleCompileStatus(context);
                    return;
                }
                if (path.EndsWith("/console", StringComparison.OrdinalIgnoreCase) && method == "GET")
                {
                    HandleConsole(context);
                    return;
                }
                if (path.EndsWith("/version", StringComparison.OrdinalIgnoreCase) && method == "GET")
                {
                    HandleVersion(context);
                    return;
                }
                if (path.EndsWith("/unused-assets", StringComparison.OrdinalIgnoreCase) && method == "GET")
                {
                    HandleUnusedAssets(context);
                    return;
                }

                SendJson(context.Response, 404, new ErrorResponse { error = "Not found" });
            }
            catch (Exception ex)
            {
                SendJson(context.Response, 500, new ErrorResponse { error = ex.Message });
            }
            finally
            {
                context.Response.Close();
            }
        }

        private static void HandlePing(HttpListenerContext context)
        {
            string body = ReadBody(context.Request);
            string projectPath = null;
            if (!string.IsNullOrWhiteSpace(body))
            {
                try
                {
                    var json = JsonUtility.FromJson<PingRequest>(body);
                    projectPath = json?.projectPath;
                }
                catch { }
            }

            string currentProject = Path.GetFullPath(".").Replace("\\", "/");
            bool match = string.IsNullOrWhiteSpace(projectPath) ||
                         string.Equals(currentProject, projectPath.Replace("\\", "/"), StringComparison.OrdinalIgnoreCase);

            SendJson(context.Response, 200, new PingResponse
            {
                connected = true,
                projectPath = currentProject,
                projectMatch = match
            });
        }

        private static void HandleIndex(HttpListenerContext context)
        {
            var snapshot = CodeIndex.GetSnapshot();
            var scripts = ProjectScanner.GetAllScriptsInAssets();
            var asmdefs = ProjectScanner.GetAllAsmdefs();
            string manifest = ProjectScanner.GetManifestJson() ?? "";

            var scriptEntries = new List<IndexScriptEntry>();
            foreach (var s in scripts)
            {
                scriptEntries.Add(new IndexScriptEntry
                {
                    path = s.path,
                    content = s.content ?? "",
                    contentLength = s.content?.Length ?? 0
                });
            }

            var asmdefEntries = new List<IndexAsmdefEntry>();
            foreach (var a in asmdefs)
            {
                asmdefEntries.Add(new IndexAsmdefEntry { path = a.path });
            }

            var prefabs = ProjectScanner.GetAllPrefabsInAssets();
            var prefabEntries = new List<IndexPrefabEntry>();
            foreach (var p in prefabs)
            {
                prefabEntries.Add(new IndexPrefabEntry
                {
                    path = p.path,
                    content = p.content ?? ""
                });
            }

            var materials = ProjectScanner.GetAllMaterialsInAssets();
            var materialEntries = new List<IndexMaterialEntry>();
            foreach (var m in materials)
            {
                materialEntries.Add(new IndexMaterialEntry { path = m.path, content = m.content ?? "" });
            }

            var shaders = ProjectScanner.GetAllShadersInAssets();
            var shaderEntries = new List<IndexShaderEntry>();
            foreach (var s in shaders)
            {
                shaderEntries.Add(new IndexShaderEntry { path = s.path, content = s.content ?? "" });
            }

            var inputActions = ProjectScanner.GetAllInputActionsInAssets();
            var inputActionEntries = new List<IndexInputActionEntry>();
            foreach (var ia in inputActions)
            {
                inputActionEntries.Add(new IndexInputActionEntry { path = ia.path, content = ia.content ?? "" });
            }

            var scriptableObjects = ProjectScanner.GetAllScriptableObjectsInAssets();
            var scriptableObjectEntries = new List<IndexScriptableObjectEntry>();
            foreach (var so in scriptableObjects)
            {
                scriptableObjectEntries.Add(new IndexScriptableObjectEntry
                {
                    path = so.path,
                    content = so.content ?? "",
                    assetType = so.assetType ?? ""
                });
            }

            var packages = ProjectScanner.GetPackagesInfo();
            var packageEntries = new List<IndexPackageEntry>();
            foreach (var pkg in packages)
            {
                packageEntries.Add(new IndexPackageEntry
                {
                    name = pkg.name ?? "",
                    version = pkg.version ?? "",
                    path = pkg.path ?? ""
                });
            }

            string[] sceneRoots = Array.Empty<string>();
            _isPlayModeResult = false;
            try
            {
                _sceneRootsResult = null;
                _sceneRootsEvent = new ManualResetEvent(false);
                lock (QueueLock)
                {
                    MainThreadQueue.Enqueue(() =>
                    {
                        try
                        {
                            _isPlayModeResult = Application.isPlaying;
                            _sceneRootsResult = SceneHierarchyScanner.GetActiveScenePaths();
                        }
                        catch
                        {
                            _isPlayModeResult = false;
                            _sceneRootsResult = new List<string>();
                        }
                        finally
                        {
                            _sceneRootsEvent?.Set();
                        }
                    });
                }
                _sceneRootsEvent.WaitOne(5000);
                sceneRoots = _sceneRootsResult?.ToArray() ?? Array.Empty<string>();
            }
            catch
            {
                sceneRoots = Array.Empty<string>();
            }

            ComponentEntry[] components = Array.Empty<ComponentEntry>();
            try
            {
                _componentsResult = null;
                _componentsEvent = new ManualResetEvent(false);
                lock (QueueLock)
                {
                    MainThreadQueue.Enqueue(() =>
                    {
                        try
                        {
                            _componentsResult = ComponentScanner.GetActiveSceneComponents();
                        }
                        catch
                        {
                            _componentsResult = new List<ComponentEntry>();
                        }
                        finally
                        {
                            _componentsEvent?.Set();
                        }
                    });
                }
                _componentsEvent.WaitOne(5000);
                components = _componentsResult?.ToArray() ?? Array.Empty<ComponentEntry>();
            }
            catch
            {
                components = Array.Empty<ComponentEntry>();
            }

            var componentEntries = new List<IndexComponentEntry>();
            foreach (var c in components)
            {
                componentEntries.Add(new IndexComponentEntry
                {
                    gameObjectPath = c.gameObjectPath ?? "",
                    componentType = c.componentType ?? "",
                    serializedFields = c.serializedFields ?? Array.Empty<string>()
                });
            }

            var response = new IndexResponse
            {
                scripts = scriptEntries.ToArray(),
                asmdefs = asmdefEntries.ToArray(),
                prefabs = prefabEntries.ToArray(),
                materials = materialEntries.ToArray(),
                shaders = shaderEntries.ToArray(),
                inputActions = inputActionEntries.ToArray(),
                scriptableObjects = scriptableObjectEntries.ToArray(),
                packages = packageEntries.ToArray(),
                components = componentEntries.ToArray(),
                manifest = manifest,
                scriptCount = snapshot.scripts?.Length ?? 0,
                edgeCount = snapshot.edges?.Length ?? 0,
                sceneRoots = sceneRoots,
                isPlayMode = _isPlayModeResult
            };

            SendJson(context.Response, 200, response);
        }

        private static void HandlePatches(HttpListenerContext context)
        {
            string body = ReadBody(context.Request);
            if (string.IsNullOrWhiteSpace(body))
            {
                SendJson(context.Response, 400, new ErrorResponse { error = "Empty body" });
                return;
            }

            FilePatch[] patches;
            try
            {
                var wrapper = JsonUtility.FromJson<PatchRequestWrapper>(body);
                patches = wrapper?.patches ?? Array.Empty<FilePatch>();
            }
            catch (Exception ex)
            {
                SendJson(context.Response, 400, new ErrorResponse { error = $"Invalid JSON: {ex.Message}" });
                return;
            }

            _pendingPatchResults = new List<PatchResult>();
            _patchDoneEvent = new ManualResetEvent(false);

            var patchesToApply = new List<FilePatch>();
            foreach (var p in patches)
            {
                if (p != null && !string.IsNullOrWhiteSpace(p.filePath))
                    patchesToApply.Add(p);
            }

            lock (QueueLock)
            {
                MainThreadQueue.Enqueue(() => ApplyPatchesOnMainThread(patchesToApply));
            }

            _patchDoneEvent.WaitOne(30000);

            SendJson(context.Response, 200, new PatchesResponse { results = _pendingPatchResults.ToArray() });
        }

        private static void ApplyPatchesOnMainThread(List<FilePatch> patches)
        {
            try
            {
                RuntimeConsoleTracker.Clear();
                var batch = new List<LastAppliedChange>();
                bool deferRefresh = patches.Count > 1;
                foreach (var patch in patches)
                {
                    try
                    {
                        var change = PatchApplier.ApplyPatch(patch, deferRefresh);
                        batch.Add(change);
                        _pendingPatchResults.Add(new PatchResult
                        {
                            filePath = patch.filePath,
                            success = true,
                            message = "Applied",
                            originalContent = change.previousContent ?? "",
                            newContent = patch.newContent ?? ""
                        });
                    }
                    catch (Exception ex)
                    {
                        _pendingPatchResults.Add(new PatchResult
                        {
                            filePath = patch.filePath ?? "?",
                            success = false,
                            message = ex.Message
                        });
                    }
                }
                if (batch.Count > 0)
                {
                    _batchStack.Add(batch);
                    if (deferRefresh)
                        AssetDatabase.Refresh();
                }
            }
            finally
            {
                _patchDoneEvent?.Set();
            }
        }

        private static void HandleActions(HttpListenerContext context)
        {
            string body = ReadBody(context.Request);
            if (string.IsNullOrWhiteSpace(body))
            {
                SendJson(context.Response, 400, new ErrorResponse { error = "Empty body" });
                return;
            }

            EditorAction[] actions;
            try
            {
                var wrapper = JsonUtility.FromJson<ActionsRequestWrapper>(body);
                actions = wrapper?.actions ?? Array.Empty<EditorAction>();
            }
            catch (Exception ex)
            {
                SendJson(context.Response, 400, new ErrorResponse { error = $"Invalid JSON: {ex.Message}" });
                return;
            }

            _pendingActionResults = null;
            _actionsDoneEvent = new ManualResetEvent(false);

            _currentActionsCts?.Dispose();
            _currentActionsCts = new CancellationTokenSource();
            _operationInProgress = true;
            _operationProgress = 0f;
            _operationStatus = "Starting...";

            var actionsToRun = new List<EditorAction>();
            foreach (var a in actions)
            {
                if (a != null && !string.IsNullOrWhiteSpace(a.action))
                    actionsToRun.Add(a);
            }

            var actionsArray = actionsToRun.ToArray();
            Func<bool> cancelCheck = () => _currentActionsCts?.Token.IsCancellationRequested == true;
            Action<float, string> onProgress = (p, s) => { _operationProgress = p; _operationStatus = s ?? ""; };

            lock (QueueLock)
            {
                MainThreadQueue.Enqueue(() =>
                {
                    try
                    {
                        var (results, revertRecords, deferred) = SceneActionExecutor.ExecuteActions(actionsArray, cancelCheck, onProgress);
                        _pendingActionResults = results;
                        if (revertRecords != null && revertRecords.Count > 0)
                            _actionBatchStack.Add(revertRecords);
                        if (deferred != null && deferred.Count > 0)
                        {
                            void RunDeferred(object _)
                            {
                                CompilationPipeline.compilationFinished -= RunDeferred;
                                SceneActionExecutor.CurrentCancelCheck = cancelCheck;
                                try
                                {
                                    for (int i = 0; i < deferred.Count; i++)
                                    {
                                        var (idx, action) = deferred[i];
                                        if (cancelCheck())
                                        {
                                            for (int j = i; j < deferred.Count; j++)
                                                _pendingActionResults[deferred[j].Item1] = new ActionResult { success = false, message = "Operation cancelled", path = "" };
                                            break;
                                        }
                                        onProgress((i + 1) / (float)deferred.Count, $"Deferred: {action?.action ?? ""}");
                                        var pr = idx > 0 ? _pendingActionResults.Take(idx).ToArray() : Array.Empty<ActionResult>();
                                        var (result, record) = SceneActionExecutor.ExecuteSingleAction(action, pr);
                                        _pendingActionResults[idx] = result;
                                        if (record != null && _actionBatchStack.Count > 0)
                                            _actionBatchStack[_actionBatchStack.Count - 1].Add(record);
                                    }
                                }
                                catch (Exception ex)
                                {
                                    foreach (var (idx, _) in deferred)
                                        _pendingActionResults[idx] = new ActionResult { success = false, message = ex.Message, path = "" };
                                }
                                finally
                                {
                                    SceneActionExecutor.CurrentCancelCheck = null;
                                    ClearOperationState();
                                    _actionsDoneEvent?.Set();
                                }
                            }
                            if (EditorApplication.isCompiling)
                                CompilationPipeline.compilationFinished += RunDeferred;
                            else
                                EditorApplication.delayCall += () => RunDeferred(null);
                            return;
                        }
                    }
                    catch (Exception ex)
                    {
                        _pendingActionResults = new[] { new ActionResult { success = false, message = ex.Message, path = "" } };
                    }
                    finally
                    {
                        ClearOperationState();
                    }
                    _actionsDoneEvent?.Set();
                });
            }

            _actionsDoneEvent.WaitOne(60000);

            SendJson(context.Response, 200, new ActionsResponse { results = _pendingActionResults ?? Array.Empty<ActionResult>() });
        }

        private static void HandleActionsStatus(HttpListenerContext context)
        {
            var cts = _currentActionsCts;
            SendJson(context.Response, 200, new ActionsStatusResponse
            {
                inProgress = _operationInProgress,
                progress = _operationProgress,
                status = _operationStatus ?? "",
                cancellationRequested = cts != null && cts.Token.IsCancellationRequested
            });
        }

        private static void HandleActionsCancel(HttpListenerContext context)
        {
            var cts = _currentActionsCts;
            if (cts != null && !cts.Token.IsCancellationRequested)
            {
                try { cts.Cancel(); } catch { }
            }
            SendJson(context.Response, 200, new ActionsCancelResponse { cancelled = true });
        }

        private static void ClearOperationState()
        {
            _operationInProgress = false;
            _operationProgress = 0f;
            _operationStatus = "";
            _currentActionsCts?.Dispose();
            _currentActionsCts = null;
        }

        private static void HandleRevertActions(HttpListenerContext context)
        {
            string body = ReadBody(context.Request);
            int revertCount = 1;
            if (!string.IsNullOrWhiteSpace(body))
            {
                try
                {
                    var req = JsonUtility.FromJson<RevertRequest>(body);
                    if (req != null && req.count > 0)
                        revertCount = req.count;
                }
                catch { }
            }

            int batchesToRevert = Math.Min(revertCount, _actionBatchStack.Count);
            if (batchesToRevert == 0)
            {
                SendJson(context.Response, 200, new RevertResponse { reverted = true, count = 0, batchesReverted = 0 });
                return;
            }

            _revertActionsDoneEvent = new ManualResetEvent(false);
            lock (QueueLock)
            {
                MainThreadQueue.Enqueue(() =>
                {
                    try
                    {
                        for (int b = 0; b < batchesToRevert && _actionBatchStack.Count > 0; b++)
                        {
                            var batch = _actionBatchStack[_actionBatchStack.Count - 1];
                            _actionBatchStack.RemoveAt(_actionBatchStack.Count - 1);
                            SceneActionExecutor.RevertActions(batch);
                        }
                    }
                    finally
                    {
                        _revertActionsDoneEvent?.Set();
                    }
                });
            }
            _revertActionsDoneEvent.WaitOne(30000);
            SendJson(context.Response, 200, new RevertResponse { reverted = true, batchesReverted = batchesToRevert });
        }

        private static void HandleRevert(HttpListenerContext context)
        {
            string body = ReadBody(context.Request);
            int revertCount = 1;
            if (!string.IsNullOrWhiteSpace(body))
            {
                try
                {
                    var req = JsonUtility.FromJson<RevertRequest>(body);
                    if (req != null && req.count > 0)
                        revertCount = req.count;
                }
                catch { }
            }

            int batchesToRevert = Math.Min(revertCount, _batchStack.Count);
            if (batchesToRevert == 0)
            {
                SendJson(context.Response, 200, new RevertResponse { reverted = true, count = 0, batchesReverted = 0 });
                return;
            }

            _patchDoneEvent = new ManualResetEvent(false);
            lock (QueueLock)
            {
                MainThreadQueue.Enqueue(() => RevertOnMainThread(batchesToRevert));
            }
            _patchDoneEvent.WaitOne(30000);
            SendJson(context.Response, 200, new RevertResponse { reverted = true, batchesReverted = batchesToRevert });
        }

        private static void RevertOnMainThread(int batchesToRevert)
        {
            try
            {
                for (int b = 0; b < batchesToRevert && _batchStack.Count > 0; b++)
                {
                    var batch = _batchStack[_batchStack.Count - 1];
                    _batchStack.RemoveAt(_batchStack.Count - 1);
                    for (int i = batch.Count - 1; i >= 0; i--)
                    {
                        PatchApplier.RevertLastChange(batch[i]);
                    }
                }
            }
            finally
            {
                _patchDoneEvent?.Set();
            }
        }

        private static string ReadBody(HttpListenerRequest request)
        {
            if (request.InputStream == null)
                return "";
            using var reader = new StreamReader(request.InputStream, request.ContentEncoding);
            return reader.ReadToEnd();
        }

        private static void SendJson(HttpListenerResponse response, int statusCode, object obj)
        {
            response.StatusCode = statusCode;
            response.ContentType = "application/json";
            response.ContentEncoding = Encoding.UTF8;
            string json = JsonUtility.ToJson(obj);
            byte[] bytes = Encoding.UTF8.GetBytes(json);
            response.ContentLength64 = bytes.Length;
            response.OutputStream.Write(bytes, 0, bytes.Length);
        }

        private static void ProcessMainThreadQueue()
        {
            lock (QueueLock)
            {
                while (MainThreadQueue.Count > 0)
                {
                    var action = MainThreadQueue.Dequeue();
                    try
                    {
                        action?.Invoke();
                    }
                    catch (Exception ex)
                    {
                        Debug.LogException(ex);
                    }
                }
            }
        }

        [Serializable]
        private class PingRequest
        {
            public string projectPath;
        }

        [Serializable]
        private class PingResponse
        {
            public bool connected;
            public string projectPath;
            public bool projectMatch;
        }

        [Serializable]
        private class PatchRequestWrapper
        {
            public FilePatch[] patches;
        }

        [Serializable]
        private class PatchResult
        {
            public string filePath;
            public bool success;
            public string message;
            public string originalContent;
            public string newContent;
        }

        [Serializable]
        private class IndexScriptEntry
        {
            public string path;
            public string content;
            public int contentLength;
        }

        [Serializable]
        private class IndexAsmdefEntry
        {
            public string path;
        }

        [Serializable]
        private class IndexPrefabEntry
        {
            public string path;
            public string content;
        }

        [Serializable]
        private class IndexMaterialEntry
        {
            public string path;
            public string content;
        }

        [Serializable]
        private class IndexShaderEntry
        {
            public string path;
            public string content;
        }

        [Serializable]
        private class IndexInputActionEntry
        {
            public string path;
            public string content;
        }

        [Serializable]
        private class IndexScriptableObjectEntry
        {
            public string path;
            public string content;
            public string assetType;
        }

        [Serializable]
        private class IndexPackageEntry
        {
            public string name;
            public string version;
            public string path;
        }

        [Serializable]
        private class IndexComponentEntry
        {
            public string gameObjectPath;
            public string componentType;
            public string[] serializedFields;
        }

        [Serializable]
        private class IndexResponse
        {
            public IndexScriptEntry[] scripts;
            public IndexAsmdefEntry[] asmdefs;
            public IndexPrefabEntry[] prefabs;
            public IndexMaterialEntry[] materials;
            public IndexShaderEntry[] shaders;
            public IndexInputActionEntry[] inputActions;
            public IndexScriptableObjectEntry[] scriptableObjects;
            public IndexPackageEntry[] packages;
            public IndexComponentEntry[] components;
            public string manifest;
            public int scriptCount;
            public int edgeCount;
            public string[] sceneRoots;
            public bool isPlayMode;
        }

        [Serializable]
        private class PatchesResponse
        {
            public PatchResult[] results;
        }

        [Serializable]
        private class ActionsRequestWrapper
        {
            public EditorAction[] actions;
        }

        [Serializable]
        private class ActionsResponse
        {
            public ActionResult[] results;
        }

        [Serializable]
        private class ActionsStatusResponse
        {
            public bool inProgress;
            public float progress;
            public string status;
            public bool cancellationRequested;
        }

        [Serializable]
        private class ActionsCancelResponse
        {
            public bool cancelled;
        }

        [Serializable]
        private class ErrorResponse
        {
            public string error;
        }

        [Serializable]
        private class CompileStatusError
        {
            public string file;
            public int line;
            public int column;
            public string message;
        }

        [Serializable]
        private class RuntimeConsoleError
        {
            public string message;
            public string stackTrace;
            public string logType;
        }

        [Serializable]
        private class CompileStatusResponse
        {
            public bool isCompiling;
            public CompileStatusError[] errors;
            public RuntimeConsoleError[] runtimeErrors;
        }

        private static void HandleCompileStatus(HttpListenerContext context)
        {
            var errors = CompilationStatusTracker.GetErrors();
            var errorEntries = new List<CompileStatusError>();
            foreach (var e in errors)
            {
                errorEntries.Add(new CompileStatusError
                {
                    file = e.file ?? "",
                    line = e.line,
                    column = e.column,
                    message = e.message ?? ""
                });
            }
            var runtimeEntries = RuntimeConsoleTracker.GetRecentErrors();
            var runtimeErrorEntries = new List<RuntimeConsoleError>();
            foreach (var e in runtimeEntries)
            {
                runtimeErrorEntries.Add(new RuntimeConsoleError
                {
                    message = e.message ?? "",
                    stackTrace = e.stackTrace ?? "",
                    logType = e.logType ?? ""
                });
            }
            SendJson(context.Response, 200, new CompileStatusResponse
            {
                isCompiling = CompilationStatusTracker.IsCompiling,
                errors = errorEntries.ToArray(),
                runtimeErrors = runtimeErrorEntries.ToArray()
            });
        }

        [Serializable]
        private class ConsoleResponse
        {
            public string content;
            public string logFilePath;
        }

        private static void HandleConsole(HttpListenerContext context)
        {
            var content = ConsoleLogExporter.GetLogContent();
            var logFilePath = ConsoleLogExporter.GetLogFilePath() ?? "";
            SendJson(context.Response, 200, new ConsoleResponse { content = content ?? "", logFilePath = logFilePath });
        }

        [Serializable]
        private class RevertRequest
        {
            public int count;
        }

        [Serializable]
        private class RevertResponse
        {
            public bool reverted;
            public int count;
            public int batchesReverted;
        }

        [Serializable]
        private class VersionResponse
        {
            public string version;
            public string[] supportedActions;
        }

        [Serializable]
        private class UnusedAssetsResponse
        {
            public string[] unusedPaths;
        }

        private static readonly string[] SupportedActions = new[]
        {
            "createGameObject", "addComponent", "instantiatePrefab", "createPrefab", "openScene", "createScene",
            "destroyGameObject", "createTag", "createPrimitive", "reparentGameObject", "updateGameObject",
            "removeComponent", "setRectTransformLayout", "createScriptableObject", "createMaterial", "createShader",
            "updateMaterial", "printSceneHierarchy", "printGameObjects", "printAssets", "updateAssetImporter",
            "updateCanvas", "updateUIImage", "updateUIText", "createCircleSprite",
            "createUXML", "createUSS", "createUIDocument",
            "createAnimationClip", "addAnimator",
            "createUILoopingScript",
            "copyAsset", "moveAsset", "deleteAsset", "createFolder", "importAsset", "createTexture", "createSprite",
            "executeMenuItem", "enterPlayMode", "selectObject", "focusSceneView",
            "addRigidbody", "addCollider", "setColliderSize", "createPhysicMaterial",
            "createInputActions", "assignInputActions",
            "createScript", "createAssemblyDefinition", "createPackageManifest",
            "createTilemap", "createTile", "setTile", "setTiles",
            "createTimeline", "addTimelineTrack", "addTimelineClip", "addPlayableDirector",
            "createAudioClip", "addAudioSource", "createAudioMixer",
            "createLight", "updateLight", "createRenderTexture",
            "addParticleSystem", "updateParticleSystem",
            "addCamera", "addCinemachineVirtualCamera",
            "setBuildScenes", "setPlayerSettings", "switchPlatform", "executeBuild",
            "createPrefabVariant", "unpackPrefab",
            "createPanelSettings", "createThemeStyleSheet",
            "addRigidbody2D", "addCollider2D", "addSpriteRenderer", "setSortingLayer", "createSortingLayer", "createSpriteAtlas",
            "createCanvas", "addEventSystem", "addLayoutGroup", "addScrollRect",
            "createLayer",
            "addLineRenderer", "addTrailRenderer", "addReflectionProbe", "addLightProbeGroup",
            "bakeNavMesh", "addNavMeshAgent", "addNavMeshObstacle",
            "createAnimatorOverrideController", "createBlendTree", "addAvatarMask",
            "addJoint", "addCharacterController", "addCloth",
            "createTerrain", "addTerrainLayer",
            "addVideoPlayer", "addTextMeshPro", "createTMPFontAsset",
            "addPackage", "removePackage",
            "loadSceneAdditive", "unloadScene",
            "createVFXGraph", "createShaderGraph", "createSpriteAnimation", "createRuleTile",
            "markAddressable", "createAddressablesGroup", "createLocalizationTable"
        };

        private static void HandleUnusedAssets(HttpListenerContext context)
        {
            _unusedAssetsResult = null;
            _unusedAssetsEvent = new ManualResetEvent(false);
            lock (QueueLock)
            {
                MainThreadQueue.Enqueue(() =>
                {
                    try
                    {
                        var referenced = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                        var allPaths = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

                        var guids = AssetDatabase.FindAssets("t:Object", new[] { "Assets" });
                        foreach (var guid in guids)
                        {
                            var p = AssetDatabase.GUIDToAssetPath(guid);
                            if (string.IsNullOrEmpty(p) || p.EndsWith(".meta", StringComparison.OrdinalIgnoreCase))
                                continue;
                            allPaths.Add(p);
                        }

                        foreach (var p in allPaths.ToList())
                        {
                            try
                            {
                                var deps = AssetDatabase.GetDependencies(p, true);
                                foreach (var d in deps ?? Array.Empty<string>())
                                {
                                    if (!string.IsNullOrEmpty(d) && !d.EndsWith(".meta", StringComparison.OrdinalIgnoreCase))
                                        referenced.Add(d);
                                }
                            }
                            catch { }
                        }

                        foreach (var scene in EditorBuildSettings.scenes ?? Array.Empty<EditorBuildSettingsScene>())
                        {
                            if (scene == null || !scene.enabled || string.IsNullOrEmpty(scene.path))
                                continue;
                            try
                            {
                                var deps = AssetDatabase.GetDependencies(scene.path, true);
                                foreach (var d in deps ?? Array.Empty<string>())
                                {
                                    if (!string.IsNullOrEmpty(d) && !d.EndsWith(".meta", StringComparison.OrdinalIgnoreCase))
                                        referenced.Add(d);
                                }
                            }
                            catch { }
                        }

                        var resourcesGuids = AssetDatabase.FindAssets("t:Object", new[] { "Assets/Resources" });
                        foreach (var guid in resourcesGuids ?? Array.Empty<string>())
                        {
                            var p = AssetDatabase.GUIDToAssetPath(guid);
                            if (string.IsNullOrEmpty(p) || p.EndsWith(".meta", StringComparison.OrdinalIgnoreCase))
                                continue;
                            referenced.Add(p);
                            try
                            {
                                var deps = AssetDatabase.GetDependencies(p, true);
                                foreach (var d in deps ?? Array.Empty<string>())
                                {
                                    if (!string.IsNullOrEmpty(d) && !d.EndsWith(".meta", StringComparison.OrdinalIgnoreCase))
                                        referenced.Add(d);
                                }
                            }
                            catch { }
                        }

                        var streamingGuids = AssetDatabase.FindAssets("t:Object", new[] { "Assets/StreamingAssets" });
                        foreach (var guid in streamingGuids ?? Array.Empty<string>())
                        {
                            var p = AssetDatabase.GUIDToAssetPath(guid);
                            if (string.IsNullOrEmpty(p) || p.EndsWith(".meta", StringComparison.OrdinalIgnoreCase))
                                continue;
                            referenced.Add(p);
                            try
                            {
                                var deps = AssetDatabase.GetDependencies(p, true);
                                foreach (var d in deps ?? Array.Empty<string>())
                                {
                                    if (!string.IsNullOrEmpty(d) && !d.EndsWith(".meta", StringComparison.OrdinalIgnoreCase))
                                        referenced.Add(d);
                                }
                            }
                            catch { }
                        }

                        var unused = allPaths.Where(x => !referenced.Contains(x)).OrderBy(x => x).ToList();
                        _unusedAssetsResult = unused;
                    }
                    catch (Exception ex)
                    {
                        _unusedAssetsResult = new List<string>();
                        Debug.LogWarning($"[CoBuddy] Unused assets scan failed: {ex.Message}");
                    }
                    finally
                    {
                        _unusedAssetsEvent?.Set();
                    }
                });
            }
            _unusedAssetsEvent.WaitOne(120000);
            var paths = _unusedAssetsResult?.ToArray() ?? Array.Empty<string>();
            SendJson(context.Response, 200, new UnusedAssetsResponse { unusedPaths = paths });
        }

        private static void HandleVersion(HttpListenerContext context)
        {
            string version = "0.1.0";
            try
            {
                var pkg = UnityEditor.PackageManager.PackageInfo.FindForPackageName("com.opengate.cobuddy")
                    ?? UnityEditor.PackageManager.PackageInfo.FindForAssembly(typeof(BridgeServer).Assembly);
                if (pkg != null && !string.IsNullOrWhiteSpace(pkg.assetPath))
                {
                    var projectRoot = Path.GetFullPath(Path.Combine(Application.dataPath, ".."));
                    var packageJsonPath = Path.Combine(projectRoot, pkg.assetPath.Replace('/', Path.DirectorySeparatorChar), "package.json");
                    if (File.Exists(packageJsonPath))
                    {
                        try
                        {
                            var json = File.ReadAllText(packageJsonPath);
                            var match = System.Text.RegularExpressions.Regex.Match(json, @"""version""\s*:\s*""([^""]+)""");
                            if (match.Success && !string.IsNullOrWhiteSpace(match.Groups[1].Value))
                                version = match.Groups[1].Value.Trim();
                        }
                        catch { }
                    }
                }
                if (version == "0.1.0" && pkg != null && !string.IsNullOrWhiteSpace(pkg.version))
                    version = pkg.version;
                if (version == "0.1.0")
                {
                    var packagesPath = Path.Combine(Application.dataPath, "..", "Packages");
                    if (Directory.Exists(packagesPath))
                    {
                        foreach (var dir in Directory.GetDirectories(packagesPath))
                        {
                            var pj = Path.Combine(dir, "package.json");
                            if (!File.Exists(pj)) continue;
                            try
                            {
                                var json = File.ReadAllText(pj);
                                if (!json.Contains("com.opengate.cobuddy")) continue;
                                var match = System.Text.RegularExpressions.Regex.Match(json, @"""version""\s*:\s*""([^""]+)""");
                                if (match.Success && !string.IsNullOrWhiteSpace(match.Groups[1].Value))
                                {
                                    version = match.Groups[1].Value.Trim();
                                    break;
                                }
                            }
                            catch { }
                        }
                    }
                }
            }
            catch { }
            SendJson(context.Response, 200, new VersionResponse
            {
                version = version,
                supportedActions = SupportedActions
            });
        }
    }
}
