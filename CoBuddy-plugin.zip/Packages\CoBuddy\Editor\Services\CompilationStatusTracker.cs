using System;
using System.Collections.Generic;
using UnityEditor;
using UnityEditor.Compilation;
using UnityEngine;

namespace CoBuddy.Editor.Services
{
    /// <summary>
    /// Tracks Unity compilation status and collects compiler errors for the CoBuddy app.
    /// </summary>
    [InitializeOnLoad]
    public static class CompilationStatusTracker
    {
        private static bool _isCompiling;
        private static readonly List<CompilationErrorEntry> Errors = new List<CompilationErrorEntry>();
        private static readonly object Lock = new object();

        [Serializable]
        public class CompilationErrorEntry
        {
            public string file;
            public int line;
            public int column;
            public string message;
        }

        static CompilationStatusTracker()
        {
            CompilationPipeline.compilationStarted += OnCompilationStarted;
            CompilationPipeline.assemblyCompilationFinished += OnAssemblyCompilationFinished;
            CompilationPipeline.compilationFinished += OnCompilationFinished;
        }

        private static void OnCompilationStarted(object context)
        {
            lock (Lock)
            {
                _isCompiling = true;
                Errors.Clear();
            }
        }

        private static void OnAssemblyCompilationFinished(string assemblyPath, CompilerMessage[] messages)
        {
            if (messages == null)
                return;

            lock (Lock)
            {
                foreach (var msg in messages)
                {
                    if (msg.type == CompilerMessageType.Error)
                    {
                        Errors.Add(new CompilationErrorEntry
                        {
                            file = msg.file ?? "",
                            line = msg.line,
                            column = msg.column,
                            message = msg.message ?? ""
                        });
                    }
                }
            }
        }

        private static void OnCompilationFinished(object context)
        {
            lock (Lock)
            {
                _isCompiling = false;
            }
        }

        public static bool IsCompiling
        {
            get { lock (Lock) return _isCompiling; }
        }

        public static CompilationErrorEntry[] GetErrors()
        {
            lock (Lock)
            {
                return Errors.ToArray();
            }
        }
    }
}
