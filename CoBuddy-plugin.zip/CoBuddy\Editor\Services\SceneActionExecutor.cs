using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEngine;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine.SceneManagement;
using UnityEngine.UIElements;
using CoBuddy.Editor.Models;

namespace CoBuddy.Editor.Services
{
    public static class SceneActionExecutor
    {
        public static (ActionResult[] results, List<ActionRevertRecord> revertRecords) ExecuteActions(EditorAction[] actions)
        {
            if (actions == null || actions.Length == 0)
                return (Array.Empty<ActionResult>(), new List<ActionRevertRecord>());

            var results = new ActionResult[actions.Length];
            var revertRecords = new List<ActionRevertRecord>();
            for (int i = 0; i < actions.Length; i++)
            {
                var (result, record) = ExecuteActionWithRevert(actions[i]);
                results[i] = result;
                if (record != null)
                    revertRecords.Add(record);
            }
            return (results, revertRecords);
        }

        public static void RevertActions(List<ActionRevertRecord> records)
        {
            if (records == null || records.Count == 0) return;
            for (int i = records.Count - 1; i >= 0; i--)
            {
                var r = records[i];
                if (r == null || string.IsNullOrWhiteSpace(r.action)) continue;
                try
                {
                    switch (r.action.ToLowerInvariant())
                    {
                        case "creategameobject":
                        case "instantiateprefab":
                            if (!string.IsNullOrWhiteSpace(r.path))
                                RevertDestroyGameObject(r.path);
                            break;
                        case "addcomponent":
                            if (!string.IsNullOrWhiteSpace(r.targetPath) && !string.IsNullOrWhiteSpace(r.componentType))
                                RevertRemoveComponent(r.targetPath, r.componentType);
                            break;
                        case "createprefab":
                            if (!string.IsNullOrWhiteSpace(r.prefabPath))
                                RevertDeletePrefab(r.prefabPath);
                            break;
                        case "createscene":
                            if (!string.IsNullOrWhiteSpace(r.scenePath))
                                RevertDeleteScene(r.scenePath);
                            break;
                        case "createprimitive":
                            if (!string.IsNullOrWhiteSpace(r.path))
                                RevertDestroyGameObject(r.path);
                            break;
                        case "reparentgameobject":
                            if (!string.IsNullOrWhiteSpace(r.path) && !string.IsNullOrWhiteSpace(r.oldParentPath))
                                RevertReparent(r.path, r.oldParentPath);
                            break;
                        case "updategameobject":
                            if (!string.IsNullOrWhiteSpace(r.path))
                                RevertUpdateGameObject(r);
                            break;
                        case "removecomponent":
                            if (!string.IsNullOrWhiteSpace(r.targetPath) && !string.IsNullOrWhiteSpace(r.componentType))
                                RevertAddComponent(r.targetPath, r.componentType);
                            break;
                        case "setrecttransformlayout":
                            if (!string.IsNullOrWhiteSpace(r.targetPath))
                                RevertRectTransform(r);
                            break;
                        case "createscriptableobject":
                        case "creatematerial":
                        case "createshader":
                        case "createcirclesprite":
                        case "createuxml":
                        case "createuss":
                            if (!string.IsNullOrWhiteSpace(r.assetPath))
                                RevertDeleteAsset(r.assetPath);
                            break;
                        case "createuidocument":
                            if (!string.IsNullOrWhiteSpace(r.path))
                                RevertDestroyGameObject(r.path);
                            break;
                        case "updatematerial":
                            if (!string.IsNullOrWhiteSpace(r.assetPath) && !string.IsNullOrWhiteSpace(r.previousMaterialState))
                                RevertMaterialProperties(r);
                            break;
                    }
                }
                catch (Exception ex)
                {
                    Debug.LogWarning($"[CoBuddy] Revert action failed: {ex.Message}");
                }
            }
        }

        private static void RevertDestroyGameObject(string path)
        {
            var go = FindByPath(path);
            if (go != null)
                Undo.DestroyObjectImmediate(go);
        }

        private static void RevertRemoveComponent(string targetPath, string componentType)
        {
            var go = FindByPath(targetPath);
            if (go == null) return;
            var type = ResolveComponentType(componentType);
            if (type == null) return;
            var comp = go.GetComponent(type);
            if (comp != null)
                Undo.DestroyObjectImmediate(comp);
        }

        private static void RevertDeletePrefab(string prefabPath)
        {
            var projectRoot = Path.GetDirectoryName(Application.dataPath);
            var fullPath = Path.Combine(projectRoot, prefabPath.Replace('/', Path.DirectorySeparatorChar));
            if (File.Exists(fullPath))
            {
                File.Delete(fullPath);
                var metaPath = fullPath + ".meta";
                if (File.Exists(metaPath))
                    File.Delete(metaPath);
                AssetDatabase.Refresh();
            }
        }

        private static void RevertDeleteScene(string scenePath)
        {
            var projectRoot = Path.GetDirectoryName(Application.dataPath);
            var fullPath = Path.Combine(projectRoot, scenePath.Replace('/', Path.DirectorySeparatorChar));
            if (File.Exists(fullPath))
            {
                File.Delete(fullPath);
                var metaPath = fullPath + ".meta";
                if (File.Exists(metaPath))
                    File.Delete(metaPath);
                AssetDatabase.Refresh();
            }
        }

        private static void RevertReparent(string path, string oldParentPath)
        {
            var go = FindByPath(path);
            var oldParent = GetParentTransform(oldParentPath);
            if (go != null && oldParent != null)
                go.transform.SetParent(oldParent, true);
        }

        private static void RevertUpdateGameObject(ActionRevertRecord r)
        {
            var go = FindByPath(r.path);
            if (go == null) return;
            if (r.previousPosition != null && r.previousPosition.Length >= 3)
                go.transform.position = new Vector3(r.previousPosition[0], r.previousPosition[1], r.previousPosition[2]);
            if (r.previousRotation != null && r.previousRotation.Length >= 3)
                go.transform.eulerAngles = new Vector3(r.previousRotation[0], r.previousRotation[1], r.previousRotation[2]);
            if (r.previousScale != null && r.previousScale.Length >= 3)
                go.transform.localScale = new Vector3(r.previousScale[0], r.previousScale[1], r.previousScale[2]);
            if (!string.IsNullOrWhiteSpace(r.previousTag) && !go.CompareTag(r.previousTag))
            {
                try { go.tag = r.previousTag; } catch { }
            }
        }

        private static void RevertAddComponent(string targetPath, string componentType)
        {
            var go = FindByPath(targetPath);
            if (go == null) return;
            var type = ResolveComponentType(componentType);
            if (type == null) return;
            if (go.GetComponent(type) == null)
                Undo.AddComponent(go, type);
        }

        private static void RevertRectTransform(ActionRevertRecord r)
        {
            var go = FindByPath(r.targetPath);
            if (go == null) return;
            var rt = go.GetComponent<RectTransform>();
            if (rt == null) return;
            rt.anchorMin = new Vector2(r.prevAnchorMinX, r.prevAnchorMinY);
            rt.anchorMax = new Vector2(r.prevAnchorMaxX, r.prevAnchorMaxY);
            rt.anchoredPosition = new Vector2(r.prevPosX, r.prevPosY);
            rt.sizeDelta = new Vector2(r.prevSizeDeltaX, r.prevSizeDeltaY);
            rt.pivot = new Vector2(r.prevPivotX, r.prevPivotY);
        }

        private static void RevertDeleteAsset(string assetPath)
        {
            var projectRoot = Path.GetDirectoryName(Application.dataPath);
            var fullPath = Path.Combine(projectRoot, assetPath.Replace('/', Path.DirectorySeparatorChar));
            if (File.Exists(fullPath))
            {
                File.Delete(fullPath);
                var metaPath = fullPath + ".meta";
                if (File.Exists(metaPath))
                    File.Delete(metaPath);
                AssetDatabase.Refresh();
            }
        }

        private static (ActionResult result, ActionRevertRecord record) ExecuteActionWithRevert(EditorAction a)
        {
            if (a == null || string.IsNullOrWhiteSpace(a.action))
                return (Fail("Missing action"), null);

            try
            {
                switch (a.action.ToLowerInvariant())
                {
                    case "creategameobject": return CreateGameObject(a);
                    case "addcomponent": return AddComponent(a);
                    case "instantiateprefab": return InstantiatePrefab(a);
                    case "createprefab": return CreatePrefab(a);
                    case "openscene": return (OpenScene(a), null);
                    case "createscene": return CreateScene(a);
                    case "destroygameobject": return (DestroyGameObject(a), null);
                    case "createtag": return (CreateTag(a), null);
                    case "createprimitive": return CreatePrimitive(a);
                    case "reparentgameobject": return ReparentGameObject(a);
                    case "updategameobject": return UpdateGameObject(a);
                    case "removecomponent": return RemoveComponent(a);
                    case "setrecttransformlayout": return SetRectTransformLayout(a);
                    case "createscriptableobject": return CreateScriptableObject(a);
                    case "creatematerial": return CreateMaterial(a);
                    case "createshader": return CreateShader(a);
                    case "updatematerial": return UpdateMaterial(a);
                    case "printscenehierarchy": return (PrintSceneHierarchy(a), null);
                    case "printgameobjects": return (PrintGameObjects(a), null);
                    case "printassets": return (PrintAssets(a), null);
                    case "updateassetimporter": return (UpdateAssetImporter(a), null);
                    case "updatecanvas": return (UpdateCanvas(a), null);
                    case "updateuiimage": return (UpdateUIImage(a), null);
                    case "updateuitext": return (UpdateUIText(a), null);
                    case "createcirclesprite": return CreateCircleSprite(a);
                    case "createuxml": return CreateUXML(a);
                    case "createuss": return CreateUSS(a);
                    case "createuidocument": return CreateUIDocument(a);
                    default: return (Fail($"Unknown action: {a.action}"), null);
                }
            }
            catch (Exception ex)
            {
                return (Fail(ex.Message), null);
            }
        }

        private static GameObject FindByPath(string path)
        {
            if (string.IsNullOrWhiteSpace(path) || path == "/")
                return null;
            string clean = path.TrimStart('/');
            return GameObject.Find(clean);
        }

        private static Transform GetParentTransform(string parentPath)
        {
            if (string.IsNullOrWhiteSpace(parentPath) || parentPath == "/")
                return null;
            var go = FindByPath(parentPath);
            return go != null ? go.transform : null;
        }

        private static (ActionResult, ActionRevertRecord) CreateGameObject(EditorAction a)
        {
            if (string.IsNullOrWhiteSpace(a.name))
                return (Fail("createGameObject requires name"), null);

            var parent = GetParentTransform(a.parent);
            var go = new GameObject(a.name ?? "GameObject");

            if (parent != null)
            {
                go.transform.SetParent(parent, false);
            }

            if (a.position != null && a.position.Length >= 3)
            {
                go.transform.position = new Vector3(a.position[0], a.position[1], a.position[2]);
            }

            Undo.RegisterCreatedObjectUndo(go, "CoBuddy createGameObject");
            var path = GetPath(go);
            return (Ok(path), new ActionRevertRecord { action = "createGameObject", path = path });
        }

        private static (ActionResult, ActionRevertRecord) AddComponent(EditorAction a)
        {
            if (string.IsNullOrWhiteSpace(a.target))
                return (Fail("addComponent requires target"), null);
            if (string.IsNullOrWhiteSpace(a.componentType))
                return (Fail("addComponent requires componentType"), null);

            var go = FindByPath(a.target);
            if (go == null)
                return (Fail($"Target not found: {a.target}"), null);

            var type = ResolveComponentType(a.componentType);
            if (type == null)
                return (Fail($"Component type not found: {a.componentType}"), null);

            Undo.AddComponent(go, type);
            return (Ok(GetPath(go)), new ActionRevertRecord { action = "addComponent", targetPath = a.target, componentType = a.componentType });
        }

        private static Type ResolveComponentType(string componentType)
        {
            var t = Type.GetType(componentType)
                ?? Type.GetType(componentType + ", UnityEngine")
                ?? Type.GetType(componentType + ", Unity.TextMeshPro")
                ?? Type.GetType(componentType + ", UnityEngine.UI");
            if (t != null) return t;
            foreach (var asm in AppDomain.CurrentDomain.GetAssemblies())
            {
                try
                {
                    t = asm.GetType(componentType);
                    if (t != null && typeof(Component).IsAssignableFrom(t))
                        return t;
                }
                catch { }
            }
            return null;
        }

        private static (ActionResult, ActionRevertRecord) InstantiatePrefab(EditorAction a)
        {
            if (string.IsNullOrWhiteSpace(a.prefabPath))
                return (Fail("instantiatePrefab requires prefabPath"), null);

            var prefab = AssetDatabase.LoadAssetAtPath<GameObject>(a.prefabPath);
            if (prefab == null)
                return (Fail($"Prefab not found: {a.prefabPath}"), null);

            var instance = (GameObject)PrefabUtility.InstantiatePrefab(prefab);
            if (instance == null)
                return (Fail("Failed to instantiate prefab"), null);

            var parent = GetParentTransform(a.parent);
            if (parent != null)
            {
                instance.transform.SetParent(parent, false);
            }

            if (!string.IsNullOrWhiteSpace(a.name))
            {
                instance.name = a.name;
            }

            Undo.RegisterCreatedObjectUndo(instance, "CoBuddy instantiatePrefab");
            var path = GetPath(instance);
            return (Ok(path), new ActionRevertRecord { action = "instantiatePrefab", path = path });
        }

        private static (ActionResult, ActionRevertRecord) CreatePrefab(EditorAction a)
        {
            if (string.IsNullOrWhiteSpace(a.target))
                return (Fail("createPrefab requires target"), null);
            if (string.IsNullOrWhiteSpace(a.prefabPath))
                return (Fail("createPrefab requires prefabPath"), null);

            var go = FindByPath(a.target);
            if (go == null)
                return (Fail($"Target not found: {a.target}"), null);

            var dir = Path.GetDirectoryName(a.prefabPath);
            if (!string.IsNullOrEmpty(dir) && !Directory.Exists(dir))
            {
                Directory.CreateDirectory(dir);
                AssetDatabase.Refresh();
            }

            var uniquePath = AssetDatabase.GenerateUniqueAssetPath(a.prefabPath);
            bool success;
            PrefabUtility.SaveAsPrefabAssetAndConnect(go, uniquePath, InteractionMode.UserAction, out success);
            if (!success)
                return (Fail("Failed to save prefab"), null);

            return (Ok(uniquePath), new ActionRevertRecord { action = "createPrefab", prefabPath = uniquePath });
        }

        private static ActionResult OpenScene(EditorAction a)
        {
            if (string.IsNullOrWhiteSpace(a.path))
                return Fail("openScene requires path");

            var scene = EditorSceneManager.OpenScene(a.path, OpenSceneMode.Single);
            return Ok(scene.path);
        }

        private static (ActionResult, ActionRevertRecord) CreateScene(EditorAction a)
        {
            if (string.IsNullOrWhiteSpace(a.path))
                return (Fail("createScene requires path"), null);

            var dir = Path.GetDirectoryName(a.path);
            if (!string.IsNullOrEmpty(dir) && !Directory.Exists(dir))
            {
                Directory.CreateDirectory(dir);
                AssetDatabase.Refresh();
            }

            var scene = EditorSceneManager.NewScene(NewSceneSetup.DefaultGameObjects, NewSceneMode.Single);
            var saved = EditorSceneManager.SaveScene(scene, a.path);
            if (!saved)
                return (Fail("Failed to save scene"), null);

            return (Ok(a.path), new ActionRevertRecord { action = "createScene", scenePath = a.path });
        }

        private static ActionResult DestroyGameObject(EditorAction a)
        {
            if (string.IsNullOrWhiteSpace(a.path))
                return Fail("destroyGameObject requires path");

            var go = FindByPath(a.path);
            if (go == null)
                return Fail($"GameObject not found: {a.path}");

            Undo.DestroyObjectImmediate(go);
            return Ok(a.path);
        }

        private static ActionResult CreateTag(EditorAction a)
        {
            if (string.IsNullOrWhiteSpace(a.tag))
                return Fail("createTag requires tag");
            var tagName = a.tag.Trim();
            if (string.IsNullOrEmpty(tagName))
                return Fail("createTag requires non-empty tag");
            try
            {
                var tagManager = AssetDatabase.LoadAllAssetsAtPath("ProjectSettings/TagManager.asset")?[0];
                if (tagManager == null)
                    return Fail("Could not load TagManager");
                var so = new SerializedObject(tagManager);
                var tagsProp = so.FindProperty("tags");
                if (tagsProp == null)
                    return Fail("Could not find tags property");
                for (int i = 0; i < tagsProp.arraySize; i++)
                {
                    if (tagsProp.GetArrayElementAtIndex(i).stringValue == tagName)
                        return Ok(null, tagName);
                }
                if (tagsProp.arraySize >= 10000)
                    return Fail("Tag limit reached");
                tagsProp.InsertArrayElementAtIndex(tagsProp.arraySize);
                tagsProp.GetArrayElementAtIndex(tagsProp.arraySize - 1).stringValue = tagName;
                so.ApplyModifiedProperties();
                return Ok(null, tagName);
            }
            catch (Exception ex)
            {
                return Fail(ex.Message);
            }
        }

        private static (ActionResult, ActionRevertRecord) CreatePrimitive(EditorAction a)
        {
            if (string.IsNullOrWhiteSpace(a.primitiveType))
                return (Fail("createPrimitive requires primitiveType"), null);
            var pt = ParsePrimitiveType(a.primitiveType);
            if (!pt.HasValue)
                return (Fail($"Unknown primitiveType: {a.primitiveType}. Use Cube, Sphere, Capsule, Cylinder, Plane, Quad"), null);

            var go = GameObject.CreatePrimitive(pt.Value);
            if (go == null)
                return (Fail("Failed to create primitive"), null);

            if (!string.IsNullOrWhiteSpace(a.name))
                go.name = a.name;

            var parent = GetParentTransform(a.parent);
            if (parent != null)
                go.transform.SetParent(parent, false);

            if (a.position != null && a.position.Length >= 3)
                go.transform.position = new Vector3(a.position[0], a.position[1], a.position[2]);

            Undo.RegisterCreatedObjectUndo(go, "CoBuddy createPrimitive");
            var path = GetPath(go);
            return (Ok(path), new ActionRevertRecord { action = "createPrimitive", path = path });
        }

        private static PrimitiveType? ParsePrimitiveType(string s)
        {
            if (string.IsNullOrWhiteSpace(s)) return null;
            var lower = s.Trim().ToLowerInvariant();
            switch (lower)
            {
                case "cube": return PrimitiveType.Cube;
                case "sphere": return PrimitiveType.Sphere;
                case "capsule": return PrimitiveType.Capsule;
                case "cylinder": return PrimitiveType.Cylinder;
                case "plane": return PrimitiveType.Plane;
                case "quad": return PrimitiveType.Quad;
                default: return null;
            }
        }

        private static (ActionResult, ActionRevertRecord) ReparentGameObject(EditorAction a)
        {
            if (string.IsNullOrWhiteSpace(a.path))
                return (Fail("reparentGameObject requires path"), null);
            if (string.IsNullOrWhiteSpace(a.newParent))
                return (Fail("reparentGameObject requires newParent"), null);

            var go = FindByPath(a.path);
            if (go == null)
                return (Fail($"GameObject not found: {a.path}"), null);

            var newParent = GetParentTransform(a.newParent);
            if (newParent == null)
                return (Fail($"New parent not found: {a.newParent}"), null);

            var oldParentPath = go.transform.parent != null ? GetPath(go.transform.parent.gameObject) : "";
            Undo.SetTransformParent(go.transform, newParent, "CoBuddy reparentGameObject");
            return (Ok(GetPath(go)), new ActionRevertRecord { action = "reparentGameObject", path = GetPath(go), oldParentPath = oldParentPath });
        }

        private static (ActionResult, ActionRevertRecord) UpdateGameObject(EditorAction a)
        {
            if (string.IsNullOrWhiteSpace(a.path))
                return (Fail("updateGameObject requires path"), null);

            var go = FindByPath(a.path);
            if (go == null)
                return (Fail($"GameObject not found: {a.path}"), null);

            var prevPos = go.transform.position;
            var prevRot = go.transform.eulerAngles;
            var prevScale = go.transform.localScale;
            var prevTag = go.tag;

            Undo.RecordObject(go.transform, "CoBuddy updateGameObject");
            if (a.position != null && a.position.Length >= 3)
                go.transform.position = new Vector3(a.position[0], a.position[1], a.position[2]);
            if (a.rotation != null && a.rotation.Length >= 3)
                go.transform.eulerAngles = new Vector3(a.rotation[0], a.rotation[1], a.rotation[2]);
            if (a.scale != null && a.scale.Length >= 3)
                go.transform.localScale = new Vector3(a.scale[0], a.scale[1], a.scale[2]);
            if (!string.IsNullOrWhiteSpace(a.tag))
            {
                try { go.tag = a.tag.Trim(); } catch (Exception ex) { return (Fail($"Invalid tag: {ex.Message}"), null); }
            }
            return (Ok(GetPath(go)), new ActionRevertRecord
            {
                action = "updateGameObject",
                path = GetPath(go),
                previousPosition = new[] { prevPos.x, prevPos.y, prevPos.z },
                previousRotation = new[] { prevRot.x, prevRot.y, prevRot.z },
                previousScale = new[] { prevScale.x, prevScale.y, prevScale.z },
                previousTag = prevTag
            });
        }

        private static (ActionResult, ActionRevertRecord) RemoveComponent(EditorAction a)
        {
            if (string.IsNullOrWhiteSpace(a.target))
                return (Fail("removeComponent requires target"), null);
            if (string.IsNullOrWhiteSpace(a.componentType))
                return (Fail("removeComponent requires componentType"), null);

            var go = FindByPath(a.target);
            if (go == null)
                return (Fail($"Target not found: {a.target}"), null);

            var type = ResolveComponentType(a.componentType);
            if (type == null)
                return (Fail($"Component type not found: {a.componentType}"), null);

            var comp = go.GetComponent(type);
            if (comp == null)
                return (Fail($"Component {a.componentType} not found on {a.target}"), null);

            Undo.DestroyObjectImmediate(comp);
            return (Ok(GetPath(go)), new ActionRevertRecord { action = "removeComponent", targetPath = a.target, componentType = a.componentType });
        }

        private static (ActionResult, ActionRevertRecord) SetRectTransformLayout(EditorAction a)
        {
            if (string.IsNullOrWhiteSpace(a.target))
                return (Fail("setRectTransformLayout requires target"), null);

            var go = FindByPath(a.target);
            if (go == null)
                return (Fail($"Target not found: {a.target}"), null);

            var rt = go.GetComponent<RectTransform>();
            if (rt == null)
                return (Fail($"Target {a.target} has no RectTransform"), null);

            var prevAnchorMin = rt.anchorMin;
            var prevAnchorMax = rt.anchorMax;
            var prevPos = rt.anchoredPosition;
            var prevSize = rt.sizeDelta;
            var prevPivot = rt.pivot;

            Undo.RecordObject(rt, "CoBuddy setRectTransformLayout");

            rt.anchorMin = new Vector2(a.anchorMinX, a.anchorMinY);
            rt.anchorMax = new Vector2(a.anchorMaxX, a.anchorMaxY);
            rt.anchoredPosition = new Vector2(a.posX, a.posY);
            rt.sizeDelta = new Vector2(a.sizeDeltaX, a.sizeDeltaY);
            var pivotX = (a.pivotX == 0 && a.pivotY == 0) ? 0.5f : a.pivotX;
            var pivotY = (a.pivotX == 0 && a.pivotY == 0) ? 0.5f : a.pivotY;
            rt.pivot = new Vector2(pivotX, pivotY);

            return (Ok(GetPath(go)), new ActionRevertRecord
            {
                action = "setRectTransformLayout",
                targetPath = a.target,
                prevAnchorMinX = prevAnchorMin.x, prevAnchorMinY = prevAnchorMin.y,
                prevAnchorMaxX = prevAnchorMax.x, prevAnchorMaxY = prevAnchorMax.y,
                prevPosX = prevPos.x, prevPosY = prevPos.y,
                prevSizeDeltaX = prevSize.x, prevSizeDeltaY = prevSize.y,
                prevPivotX = prevPivot.x, prevPivotY = prevPivot.y
            });
        }

        private static (ActionResult, ActionRevertRecord) CreateScriptableObject(EditorAction a)
        {
            if (string.IsNullOrWhiteSpace(a.assetPath))
                return (Fail("createScriptableObject requires assetPath"), null);
            if (string.IsNullOrWhiteSpace(a.scriptableObjectType))
                return (Fail("createScriptableObject requires scriptableObjectType"), null);

            var type = ResolveScriptableObjectType(a.scriptableObjectType);
            if (type == null)
                return (Fail($"ScriptableObject type not found: {a.scriptableObjectType}"), null);

            var path = a.assetPath.Trim();
            if (!path.EndsWith(".asset", StringComparison.OrdinalIgnoreCase))
                path += ".asset";

            var dir = Path.GetDirectoryName(path);
            if (!string.IsNullOrEmpty(dir) && !Directory.Exists(dir))
            {
                Directory.CreateDirectory(dir);
                AssetDatabase.Refresh();
            }

            var uniquePath = AssetDatabase.GenerateUniqueAssetPath(path);
            var instance = ScriptableObject.CreateInstance(type);
            if (instance == null)
                return (Fail("Failed to create ScriptableObject instance"), null);

            AssetDatabase.CreateAsset(instance, uniquePath);
            AssetDatabase.SaveAssets();
            return (Ok(uniquePath), new ActionRevertRecord { action = "createScriptableObject", assetPath = uniquePath });
        }

        private static Type ResolveScriptableObjectType(string typeName)
        {
            var t = Type.GetType(typeName)
                ?? Type.GetType(typeName + ", UnityEngine")
                ?? Type.GetType(typeName + ", Assembly-CSharp");
            if (t != null && typeof(ScriptableObject).IsAssignableFrom(t))
                return t;
            foreach (var asm in AppDomain.CurrentDomain.GetAssemblies())
            {
                try
                {
                    t = asm.GetType(typeName);
                    if (t != null && typeof(ScriptableObject).IsAssignableFrom(t))
                        return t;
                }
                catch { }
            }
            return null;
        }

        private static (ActionResult, ActionRevertRecord) CreateMaterial(EditorAction a)
        {
            if (string.IsNullOrWhiteSpace(a.assetPath))
                return (Fail("createMaterial requires assetPath"), null);

            var path = a.assetPath.Trim();
            if (!path.EndsWith(".mat", StringComparison.OrdinalIgnoreCase))
                path += ".mat";

            var shaderName = !string.IsNullOrWhiteSpace(a.shaderName) ? a.shaderName.Trim() : "Standard";
            Shader shader = null;
            if (shaderName.Contains("/") || shaderName.EndsWith(".shader", StringComparison.OrdinalIgnoreCase))
            {
                shader = AssetDatabase.LoadAssetAtPath<Shader>(shaderName);
            }
            if (shader == null)
                shader = Shader.Find(shaderName);
            if (shader == null)
                shader = Shader.Find("Standard");
            if (shader == null)
                return (Fail($"Shader not found: {shaderName}"), null);

            var dir = Path.GetDirectoryName(path);
            if (!string.IsNullOrEmpty(dir) && !Directory.Exists(dir))
            {
                Directory.CreateDirectory(dir);
                AssetDatabase.Refresh();
            }

            var uniquePath = AssetDatabase.GenerateUniqueAssetPath(path);
            var mat = new Material(shader);
            AssetDatabase.CreateAsset(mat, uniquePath);
            AssetDatabase.SaveAssets();
            return (Ok(uniquePath), new ActionRevertRecord { action = "createMaterial", assetPath = uniquePath });
        }

        private static (ActionResult, ActionRevertRecord) CreateShader(EditorAction a)
        {
            if (string.IsNullOrWhiteSpace(a.assetPath))
                return (Fail("createShader requires assetPath"), null);
            if (string.IsNullOrWhiteSpace(a.shaderSource))
                return (Fail("createShader requires shaderSource"), null);

            var source = a.shaderSource.Trim();
            if (source.Length < 10 || !source.Contains("Shader") || !source.Contains("{"))
                return (Fail("createShader requires valid ShaderLab source (must contain Shader and {)"), null);
            if (source.Length > 65536)
                source = source.Substring(0, 65536);

            var path = a.assetPath.Trim();
            if (!path.EndsWith(".shader", StringComparison.OrdinalIgnoreCase))
                path += ".shader";

            var dir = Path.GetDirectoryName(path);
            if (!string.IsNullOrEmpty(dir) && !Directory.Exists(dir))
            {
                Directory.CreateDirectory(dir);
            }

            var uniquePath = AssetDatabase.GenerateUniqueAssetPath(path);
            var fullPath = Path.GetFullPath(uniquePath);
            File.WriteAllText(fullPath, source);
            AssetDatabase.Refresh();
            return (Ok(uniquePath), new ActionRevertRecord { action = "createShader", assetPath = uniquePath });
        }

        private static (ActionResult, ActionRevertRecord) UpdateMaterial(EditorAction a)
        {
            if (string.IsNullOrWhiteSpace(a.assetPath))
                return (Fail("updateMaterial requires assetPath"), null);
            if (string.IsNullOrWhiteSpace(a.materialProperties))
                return (Fail("updateMaterial requires materialProperties"), null);

            var path = a.assetPath.Trim();
            if (!path.EndsWith(".mat", StringComparison.OrdinalIgnoreCase))
                path += ".mat";

            var mat = AssetDatabase.LoadAssetAtPath<Material>(path);
            if (mat == null)
                return (Fail($"Material not found: {path}"), null);

            var props = ParseMaterialPropertiesJson(a.materialProperties.Trim());
            if (props == null || props.Count == 0)
                return (Fail("invalid materialProperties JSON"), null);

            var previousState = new Dictionary<string, object>();
            foreach (var kv in props)
            {
                try
                {
                    if (mat.HasProperty(kv.Key))
                    {
                        var propType = GetMaterialPropertyType(mat, kv.Key);
                        if (propType == MaterialPropertyType.Color)
                        {
                            previousState[kv.Key] = mat.GetColor(kv.Key);
                        }
                        else if (propType == MaterialPropertyType.Float || propType == MaterialPropertyType.Range)
                        {
                            previousState[kv.Key] = mat.GetFloat(kv.Key);
                        }
                        else if (propType == MaterialPropertyType.Int)
                        {
                            previousState[kv.Key] = mat.GetInteger(kv.Key);
                        }
                        else if (propType == MaterialPropertyType.Texture)
                        {
                            var tex = mat.GetTexture(kv.Key);
                            previousState[kv.Key] = tex != null ? AssetDatabase.GetAssetPath(tex) : "";
                        }
                    }
                }
                catch { }
            }

            foreach (var kv in props)
            {
                try
                {
                    if (!mat.HasProperty(kv.Key)) continue;
                    if (kv.Value is float[] arr && arr.Length >= 4)
                    {
                        mat.SetColor(kv.Key, new Color(arr[0], arr[1], arr[2], arr.Length > 3 ? arr[3] : 1f));
                    }
                    else if (kv.Value is float f)
                    {
                        mat.SetFloat(kv.Key, f);
                    }
                    else if (kv.Value is int i)
                    {
                        mat.SetInteger(kv.Key, i);
                    }
                    else if (kv.Value is string s && !string.IsNullOrEmpty(s))
                    {
                        var tex = AssetDatabase.LoadAssetAtPath<Texture>(s);
                        if (tex != null)
                            mat.SetTexture(kv.Key, tex);
                    }
                }
                catch (Exception ex)
                {
                    Debug.LogWarning($"[CoBuddy] updateMaterial: failed to set {kv.Key}: {ex.Message}");
                }
            }

            EditorUtility.SetDirty(mat);
            AssetDatabase.SaveAssets();

            var prevJson = SerializeMaterialStateForRevert(previousState);
            return (Ok(path), new ActionRevertRecord { action = "updateMaterial", assetPath = path, previousMaterialState = prevJson });
        }

        private enum MaterialPropertyType { Unknown, Float, Int, Color, Texture, Range }
        private static MaterialPropertyType GetMaterialPropertyType(Material mat, string name)
        {
            for (int i = 0; i < mat.shader.GetPropertyCount(); i++)
            {
                if (mat.shader.GetPropertyName(i) == name)
                {
                    var t = mat.shader.GetPropertyType(i);
                    if (t == UnityEngine.Rendering.ShaderPropertyType.Color || t == UnityEngine.Rendering.ShaderPropertyType.Vector)
                        return MaterialPropertyType.Color;
                    if (t == UnityEngine.Rendering.ShaderPropertyType.Float || t == UnityEngine.Rendering.ShaderPropertyType.Range)
                        return MaterialPropertyType.Float;
                    if (t == UnityEngine.Rendering.ShaderPropertyType.Texture)
                        return MaterialPropertyType.Texture;
                    if (t == UnityEngine.Rendering.ShaderPropertyType.Int)
                        return MaterialPropertyType.Int;
                    return MaterialPropertyType.Unknown;
                }
            }
            return MaterialPropertyType.Unknown;
        }

        private static Dictionary<string, object> ParseMaterialPropertiesJson(string json)
        {
            var result = new Dictionary<string, object>();
            if (string.IsNullOrWhiteSpace(json) || !json.StartsWith("{")) return result;
            int i = 1;
            while (i < json.Length)
            {
                var key = ParseJsonString(json, ref i);
                if (key == null) break;
                SkipWhitespace(json, ref i);
                if (i >= json.Length || json[i] != ':') break;
                i++;
                SkipWhitespace(json, ref i);
                if (i >= json.Length) break;
                object val = null;
                if (json[i] == '[')
                {
                    val = ParseJsonNumberArray(json, ref i);
                }
                else if (json[i] == '"')
                {
                    val = ParseJsonString(json, ref i);
                }
                else if (json[i] == '-' || json[i] == '.' || char.IsDigit(json[i]))
                {
                    val = ParseJsonNumberValue(json, ref i);
                }
                if (val != null)
                    result[key] = val;
                SkipWhitespace(json, ref i);
                if (i < json.Length && json[i] == ',') { i++; SkipWhitespace(json, ref i); }
            }
            return result;
        }
        private static void SkipWhitespace(string s, ref int i) { while (i < s.Length && char.IsWhiteSpace(s[i])) i++; }
        private static string ParseJsonString(string s, ref int i)
        {
            if (i >= s.Length || s[i] != '"') return null;
            i++;
            var sb = new System.Text.StringBuilder();
            while (i < s.Length && s[i] != '"')
            {
                if (s[i] == '\\') { i++; if (i < s.Length) sb.Append(s[i++]); }
                else sb.Append(s[i++]);
            }
            if (i < s.Length) i++;
            return sb.ToString();
        }
        private static float[] ParseJsonNumberArray(string s, ref int i)
        {
            if (i >= s.Length || s[i] != '[') return null;
            i++;
            var list = new List<float>();
            SkipWhitespace(s, ref i);
            while (i < s.Length && s[i] != ']')
            {
                var n = ParseJsonNumber(s, ref i);
                if (n.HasValue) list.Add(n.Value);
                SkipWhitespace(s, ref i);
                if (i < s.Length && s[i] == ',') { i++; SkipWhitespace(s, ref i); }
            }
            if (i < s.Length) i++;
            return list.ToArray();
        }
        private static float? ParseJsonNumber(string s, ref int i)
        {
            SkipWhitespace(s, ref i);
            int start = i;
            while (i < s.Length && (char.IsDigit(s[i]) || s[i] == '-' || s[i] == '.' || s[i] == 'e' || s[i] == 'E' || s[i] == '+')) i++;
            if (i == start) return null;
            return float.TryParse(s.Substring(start, i - start), System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out float v) ? v : (float?)null;
        }
        private static object ParseJsonNumberValue(string s, ref int i)
        {
            SkipWhitespace(s, ref i);
            int start = i;
            while (i < s.Length && (char.IsDigit(s[i]) || s[i] == '-' || s[i] == '.' || s[i] == 'e' || s[i] == 'E' || s[i] == '+')) i++;
            if (i == start) return null;
            var sub = s.Substring(start, i - start);
            if (sub.Contains(".") || sub.ToLowerInvariant().Contains("e"))
                return float.TryParse(sub, System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out float f) ? (object)f : null;
            return int.TryParse(sub, System.Globalization.NumberStyles.Integer, System.Globalization.CultureInfo.InvariantCulture, out int n) ? (object)n : null;
        }
        private static string SerializeMaterialStateForRevert(Dictionary<string, object> state)
        {
            var sb = new System.Text.StringBuilder();
            sb.Append("{");
            bool first = true;
            foreach (var kv in state)
            {
                if (!first) sb.Append(",");
                first = false;
                sb.Append("\"").Append(kv.Key.Replace("\\", "\\\\").Replace("\"", "\\\"")).Append("\":");
                if (kv.Value is Color c)
                    sb.Append("[").Append(c.r.ToString("R", System.Globalization.CultureInfo.InvariantCulture)).Append(",").Append(c.g.ToString("R", System.Globalization.CultureInfo.InvariantCulture)).Append(",").Append(c.b.ToString("R", System.Globalization.CultureInfo.InvariantCulture)).Append(",").Append(c.a.ToString("R", System.Globalization.CultureInfo.InvariantCulture)).Append("]");
                else if (kv.Value is float f)
                    sb.Append(f.ToString("R", System.Globalization.CultureInfo.InvariantCulture));
                else if (kv.Value is int n)
                    sb.Append(n);
                else if (kv.Value is string str)
                    sb.Append("\"").Append(str.Replace("\\", "\\\\").Replace("\"", "\\\"")).Append("\"");
                else
                    sb.Append("null");
            }
            sb.Append("}");
            return sb.ToString();
        }
        private static void RevertMaterialProperties(ActionRevertRecord r)
        {
            var mat = AssetDatabase.LoadAssetAtPath<Material>(r.assetPath);
            if (mat == null) return;
            var props = ParseMaterialPropertiesJson(r.previousMaterialState);
            if (props == null || props.Count == 0) return;
            foreach (var kv in props)
            {
                try
                {
                    if (!mat.HasProperty(kv.Key)) continue;
                    if (kv.Value is float[] arr && arr.Length >= 4)
                    {
                        mat.SetColor(kv.Key, new Color(arr[0], arr[1], arr[2], arr.Length > 3 ? arr[3] : 1f));
                    }
                    else if (kv.Value is float f)
                    {
                        mat.SetFloat(kv.Key, f);
                    }
                    else if (kv.Value is int i)
                    {
                        mat.SetInteger(kv.Key, i);
                    }
                    else if (kv.Value is string s)
                    {
                        var tex = string.IsNullOrEmpty(s) ? null : AssetDatabase.LoadAssetAtPath<Texture>(s);
                        mat.SetTexture(kv.Key, tex);
                    }
                }
                catch { }
            }
            EditorUtility.SetDirty(mat);
            AssetDatabase.SaveAssets();
        }

        private static ActionResult PrintSceneHierarchy(EditorAction a)
        {
            var paths = new List<string>();
            var scene = SceneManager.GetActiveScene();
            var roots = scene.GetRootGameObjects();
            foreach (var root in roots)
                CollectPaths(root.transform, "", paths);
            var json = "[" + string.Join(",", paths.Select(p => "\"" + p.Replace("\\", "\\\\").Replace("\"", "\\\"") + "\"")) + "]";
            return Ok(null, json);
        }

        private static void CollectPaths(Transform t, string prefix, List<string> paths)
        {
            var name = string.IsNullOrEmpty(prefix) ? t.name : prefix + "/" + t.name;
            paths.Add(name);
            for (int i = 0; i < t.childCount; i++)
                CollectPaths(t.GetChild(i), name, paths);
        }

        private static ActionResult PrintGameObjects(EditorAction a)
        {
            var list = new List<Dictionary<string, string>>();
            var scene = SceneManager.GetActiveScene();
            var roots = scene.GetRootGameObjects();
            var filter = !string.IsNullOrWhiteSpace(a.path) ? a.path.Trim() : null;
            foreach (var root in roots)
                CollectGameObjects(root.transform, "", filter, list);
            var sb = new System.Text.StringBuilder();
            sb.Append("[");
            for (int i = 0; i < list.Count; i++)
            {
                if (i > 0) sb.Append(",");
                var d = list[i];
                sb.Append("{\"path\":\"").Append(EscapeJson(d["path"])).Append("\",\"name\":\"").Append(EscapeJson(d["name"]))
                    .Append("\",\"tag\":\"").Append(EscapeJson(d["tag"])).Append("\",\"layer\":\"").Append(EscapeJson(d["layer"])).Append("\"}");
            }
            sb.Append("]");
            return Ok(null, sb.ToString());
        }

        private static void CollectGameObjects(Transform t, string prefix, string filter, List<Dictionary<string, string>> list)
        {
            var path = string.IsNullOrEmpty(prefix) ? t.name : prefix + "/" + t.name;
            if (filter == null || path.StartsWith(filter, StringComparison.OrdinalIgnoreCase))
            {
                list.Add(new Dictionary<string, string>
                {
                    { "path", path },
                    { "name", t.gameObject.name },
                    { "tag", t.gameObject.tag },
                    { "layer", LayerMask.LayerToName(t.gameObject.layer) }
                });
            }
            for (int i = 0; i < t.childCount; i++)
                CollectGameObjects(t.GetChild(i), path, filter, list);
        }

        private static string EscapeJson(string s)
        {
            if (string.IsNullOrEmpty(s)) return "";
            return s.Replace("\\", "\\\\").Replace("\"", "\\\"").Replace("\n", "\\n").Replace("\r", "\\r");
        }

        private static ActionResult PrintAssets(EditorAction a)
        {
            var folder = !string.IsNullOrWhiteSpace(a.folder) ? a.folder.Trim() : "Assets";
            if (!folder.StartsWith("Assets", StringComparison.OrdinalIgnoreCase))
                folder = "Assets/" + folder.TrimStart('/');
            var guids = AssetDatabase.FindAssets("t:Object", new[] { folder });
            var paths = guids.Select(g => AssetDatabase.GUIDToAssetPath(g)).Where(p => !string.IsNullOrEmpty(p)).ToList();
            var json = "[" + string.Join(",", paths.Select(p => "\"" + EscapeJson(p) + "\"")) + "]";
            return Ok(null, json);
        }

        private static ActionResult UpdateAssetImporter(EditorAction a)
        {
            var path = !string.IsNullOrWhiteSpace(a.assetPath) ? a.assetPath.Trim() : (a.path ?? "").Trim();
            if (string.IsNullOrEmpty(path))
                return Fail("updateAssetImporter requires assetPath or path");

            var importer = AssetImporter.GetAtPath(path);
            if (importer == null)
                return Fail($"Asset not found: {path}");

            var textureImporter = importer as TextureImporter;
            if (textureImporter != null && a.maxTextureSize > 0)
            {
                Undo.RecordObject(textureImporter, "CoBuddy updateAssetImporter");
                textureImporter.maxTextureSize = a.maxTextureSize;
                textureImporter.SaveAndReimport();
                return Ok(path);
            }

            if (textureImporter == null)
                return Fail($"Asset at {path} is not a texture; only TextureImporter (maxTextureSize) is supported");
            return Fail("updateAssetImporter requires maxTextureSize > 0 for textures");
        }

        private static ActionResult UpdateCanvas(EditorAction a)
        {
            if (string.IsNullOrWhiteSpace(a.target))
                return Fail("updateCanvas requires target");
            var go = FindByPath(a.target);
            if (go == null)
                return Fail($"Target not found: {a.target}");
            var canvas = go.GetComponent<UnityEngine.Canvas>();
            if (canvas == null)
                return Fail($"Target {a.target} has no Canvas component");
            var modeStr = (a.renderMode ?? "").Trim();
            if (string.IsNullOrEmpty(modeStr))
                return Fail("updateCanvas requires renderMode (ScreenSpaceOverlay, ScreenSpaceCamera, WorldSpace)");
            UnityEngine.RenderMode mode;
            switch (modeStr.ToLowerInvariant())
            {
                case "screenspaceoverlay":
                case "screen space overlay":
                case "overlay":
                    mode = UnityEngine.RenderMode.ScreenSpaceOverlay;
                    break;
                case "screenspacecamera":
                case "screen space camera":
                case "camera":
                    mode = UnityEngine.RenderMode.ScreenSpaceCamera;
                    break;
                case "worldspace":
                case "world space":
                case "world":
                    mode = UnityEngine.RenderMode.WorldSpace;
                    break;
                default:
                    return Fail($"Unknown renderMode: {modeStr}. Use ScreenSpaceOverlay, ScreenSpaceCamera, or WorldSpace");
            }
            Undo.RecordObject(canvas, "CoBuddy updateCanvas");
            canvas.renderMode = mode;
            return Ok(GetPath(go));
        }

        private static ActionResult UpdateUIImage(EditorAction a)
        {
            if (string.IsNullOrWhiteSpace(a.target))
                return Fail("updateUIImage requires target");
            var go = FindByPath(a.target);
            if (go == null)
                return Fail($"Target not found: {a.target}");
            var img = go.GetComponent<UnityEngine.UI.Image>();
            if (img == null)
                return Fail($"Target {a.target} has no Image component");
            Undo.RecordObject(img, "CoBuddy updateUIImage");
            Color? newColor = null;
            if (a.color != null && a.color.Length >= 3)
            {
                var r = a.color[0]; var g = a.color[1]; var b = a.color[2];
                if (r > 1 || g > 1 || b > 1) { r /= 255f; g /= 255f; b /= 255f; }
                var alpha = a.color.Length >= 4 ? a.color[3] : 1f;
                if (alpha > 1) alpha /= 255f;
                newColor = new Color(r, g, b, alpha);
            }
            else if (a.colorR >= 0 || a.colorG >= 0 || a.colorB >= 0 || a.colorA >= 0)
            {
                var r = a.colorR >= 0 ? (a.colorR > 1 ? a.colorR / 255f : a.colorR) : img.color.r;
                var g = a.colorG >= 0 ? (a.colorG > 1 ? a.colorG / 255f : a.colorG) : img.color.g;
                var b = a.colorB >= 0 ? (a.colorB > 1 ? a.colorB / 255f : a.colorB) : img.color.b;
                var alpha = a.colorA >= 0 ? (a.colorA > 1 ? a.colorA / 255f : a.colorA) : img.color.a;
                newColor = new Color(r, g, b, alpha);
            }
            if (newColor.HasValue)
                img.color = newColor.Value;
            if (!string.IsNullOrWhiteSpace(a.imageType))
            {
                var t = a.imageType.Trim().ToLowerInvariant();
                if (t == "simple") img.type = UnityEngine.UI.Image.Type.Simple;
                else if (t == "sliced") img.type = UnityEngine.UI.Image.Type.Sliced;
                else if (t == "tiled") img.type = UnityEngine.UI.Image.Type.Tiled;
                else if (t == "filled") img.type = UnityEngine.UI.Image.Type.Filled;
            }
            if (!string.IsNullOrWhiteSpace(a.spritePath))
            {
                var sprite = AssetDatabase.LoadAssetAtPath<UnityEngine.Sprite>(a.spritePath.Trim());
                if (sprite != null)
                    img.sprite = sprite;
            }
            return Ok(GetPath(go));
        }

        private static ActionResult UpdateUIText(EditorAction a)
        {
            if (string.IsNullOrWhiteSpace(a.target))
                return Fail("updateUIText requires target");
            var go = FindByPath(a.target);
            if (go == null)
                return Fail($"Target not found: {a.target}");
            var text = go.GetComponent<UnityEngine.UI.Text>();
            if (text == null)
                return Fail($"Target {a.target} has no Text component");
            Undo.RecordObject(text, "CoBuddy updateUIText");
            if (a.text != null)
                text.text = a.text;
            Color? newColor = null;
            if (a.color != null && a.color.Length >= 3)
            {
                var r = a.color[0]; var g = a.color[1]; var b = a.color[2];
                if (r > 1 || g > 1 || b > 1) { r /= 255f; g /= 255f; b /= 255f; }
                var alpha = a.color.Length >= 4 ? a.color[3] : 1f;
                if (alpha > 1) alpha /= 255f;
                newColor = new Color(r, g, b, alpha);
            }
            else if (a.colorR >= 0 || a.colorG >= 0 || a.colorB >= 0 || a.colorA >= 0)
            {
                var r = a.colorR >= 0 ? (a.colorR > 1 ? a.colorR / 255f : a.colorR) : text.color.r;
                var g = a.colorG >= 0 ? (a.colorG > 1 ? a.colorG / 255f : a.colorG) : text.color.g;
                var b = a.colorB >= 0 ? (a.colorB > 1 ? a.colorB / 255f : a.colorB) : text.color.b;
                var alpha = a.colorA >= 0 ? (a.colorA > 1 ? a.colorA / 255f : a.colorA) : text.color.a;
                newColor = new Color(r, g, b, alpha);
            }
            if (newColor.HasValue)
                text.color = newColor.Value;
            if (a.fontSize > 0)
                text.fontSize = a.fontSize;
            if (!string.IsNullOrWhiteSpace(a.alignment))
            {
                var align = a.alignment.Trim().ToLowerInvariant();
                UnityEngine.TextAnchor anchor;
                switch (align)
                {
                    case "upperleft": anchor = UnityEngine.TextAnchor.UpperLeft; break;
                    case "uppercenter":
                    case "uppercentre": anchor = UnityEngine.TextAnchor.UpperCenter; break;
                    case "upperright": anchor = UnityEngine.TextAnchor.UpperRight; break;
                    case "middleleft": anchor = UnityEngine.TextAnchor.MiddleLeft; break;
                    case "middlecenter":
                    case "middlecentre":
                    case "center":
                    case "centre": anchor = UnityEngine.TextAnchor.MiddleCenter; break;
                    case "middleright": anchor = UnityEngine.TextAnchor.MiddleRight; break;
                    case "lowerleft": anchor = UnityEngine.TextAnchor.LowerLeft; break;
                    case "lowercenter":
                    case "lowercentre": anchor = UnityEngine.TextAnchor.LowerCenter; break;
                    case "lowerright": anchor = UnityEngine.TextAnchor.LowerRight; break;
                    default: anchor = UnityEngine.TextAnchor.MiddleCenter; break;
                }
                text.alignment = anchor;
            }
            return Ok(GetPath(go));
        }

        private static (ActionResult, ActionRevertRecord) CreateUXML(EditorAction a)
        {
            if (string.IsNullOrWhiteSpace(a.assetPath))
                return (Fail("createUXML requires assetPath"), null);
            if (string.IsNullOrWhiteSpace(a.content))
                return (Fail("createUXML requires content"), null);

            var path = a.assetPath.Trim();
            if (!path.EndsWith(".uxml", StringComparison.OrdinalIgnoreCase))
                path += ".uxml";

            var dir = Path.GetDirectoryName(path);
            if (!string.IsNullOrEmpty(dir) && !Directory.Exists(dir))
            {
                Directory.CreateDirectory(dir);
                AssetDatabase.Refresh();
            }

            var uniquePath = AssetDatabase.GenerateUniqueAssetPath(path);
            var fullPath = Path.Combine(Path.GetDirectoryName(Application.dataPath), uniquePath.Replace('/', Path.DirectorySeparatorChar));
            File.WriteAllText(fullPath, a.content.Trim());
            AssetDatabase.Refresh();
            return (Ok(uniquePath), new ActionRevertRecord { action = "createUXML", assetPath = uniquePath });
        }

        private static (ActionResult, ActionRevertRecord) CreateUSS(EditorAction a)
        {
            if (string.IsNullOrWhiteSpace(a.assetPath))
                return (Fail("createUSS requires assetPath"), null);
            if (string.IsNullOrWhiteSpace(a.content))
                return (Fail("createUSS requires content"), null);

            var path = a.assetPath.Trim();
            if (!path.EndsWith(".uss", StringComparison.OrdinalIgnoreCase))
                path += ".uss";

            var dir = Path.GetDirectoryName(path);
            if (!string.IsNullOrEmpty(dir) && !Directory.Exists(dir))
            {
                Directory.CreateDirectory(dir);
                AssetDatabase.Refresh();
            }

            var uniquePath = AssetDatabase.GenerateUniqueAssetPath(path);
            var fullPath = Path.Combine(Path.GetDirectoryName(Application.dataPath), uniquePath.Replace('/', Path.DirectorySeparatorChar));
            File.WriteAllText(fullPath, a.content.Trim());
            AssetDatabase.Refresh();
            return (Ok(uniquePath), new ActionRevertRecord { action = "createUSS", assetPath = uniquePath });
        }

        private static (ActionResult, ActionRevertRecord) CreateUIDocument(EditorAction a)
        {
            if (string.IsNullOrWhiteSpace(a.uxmlPath))
                return (Fail("createUIDocument requires uxmlPath"), null);

            var uxmlPath = a.uxmlPath.Trim();
            var treeAsset = AssetDatabase.LoadAssetAtPath<VisualTreeAsset>(uxmlPath);
            if (treeAsset == null)
                return (Fail($"UXML not found: {uxmlPath}. Create UXML first."), null);

            var name = !string.IsNullOrWhiteSpace(a.name) ? a.name.Trim() : "UI_Document";
            var go = new GameObject(name);
            Undo.RegisterCreatedObjectUndo(go, "CoBuddy createUIDocument");

            var uiDoc = go.AddComponent<UIDocument>();
            uiDoc.visualTreeAsset = treeAsset;

            if (!string.IsNullOrWhiteSpace(a.panelSettingsPath))
            {
                var panelSettings = AssetDatabase.LoadAssetAtPath<PanelSettings>(a.panelSettingsPath.Trim());
                if (panelSettings != null)
                    uiDoc.panelSettings = panelSettings;
            }
            else
            {
                var defaultPanel = AssetDatabase.FindAssets("t:PanelSettings").Select(AssetDatabase.GUIDToAssetPath).FirstOrDefault(p => !string.IsNullOrEmpty(p));
                if (!string.IsNullOrEmpty(defaultPanel))
                    uiDoc.panelSettings = AssetDatabase.LoadAssetAtPath<PanelSettings>(defaultPanel);
            }

            var pathStr = GetPath(go);
            return (Ok(pathStr), new ActionRevertRecord { action = "createUIDocument", path = pathStr });
        }

        private static (ActionResult, ActionRevertRecord) CreateCircleSprite(EditorAction a)
        {
            var path = !string.IsNullOrWhiteSpace(a.assetPath) ? a.assetPath.Trim() : "Assets/Textures/CoBuddyCircle.png";
            if (!path.EndsWith(".png", StringComparison.OrdinalIgnoreCase))
                path += ".png";
            var size = a.spriteSize > 0 ? a.spriteSize : 128;
            size = Mathf.Clamp(size, 16, 512);
            var dir = Path.GetDirectoryName(path);
            if (!string.IsNullOrEmpty(dir) && !Directory.Exists(dir))
            {
                Directory.CreateDirectory(dir);
                AssetDatabase.Refresh();
            }
            var uniquePath = AssetDatabase.GenerateUniqueAssetPath(path);
            var tex = new Texture2D(size, size);
            var center = size / 2f;
            var radius = center - 1;
            for (int y = 0; y < size; y++)
                for (int x = 0; x < size; x++)
                {
                    var dx = x - center;
                    var dy = y - center;
                    var dist = Mathf.Sqrt(dx * dx + dy * dy);
                    tex.SetPixel(x, y, dist <= radius ? Color.white : Color.clear);
                }
            tex.Apply();
            var bytes = tex.EncodeToPNG();
            UnityEngine.Object.DestroyImmediate(tex);
            File.WriteAllBytes(Path.Combine(Path.GetDirectoryName(Application.dataPath), uniquePath.Replace('/', Path.DirectorySeparatorChar)), bytes);
            AssetDatabase.Refresh();
            var importer = AssetImporter.GetAtPath(uniquePath) as TextureImporter;
            if (importer != null)
            {
                importer.textureType = TextureImporterType.Sprite;
                importer.spritePixelsPerUnit = 100;
                importer.SaveAndReimport();
            }
            return (Ok(uniquePath), new ActionRevertRecord { action = "createCircleSprite", assetPath = uniquePath });
        }

        private static string GetPath(GameObject go)
        {
            if (go == null) return "";
            var parts = new System.Collections.Generic.List<string>();
            var t = go.transform;
            while (t != null)
            {
                parts.Insert(0, t.gameObject.name);
                t = t.parent;
            }
            return string.Join("/", parts);
        }

        private static ActionResult Ok(string path = null, string data = null)
        {
            return new ActionResult { success = true, message = "OK", path = path ?? "", data = data };
        }

        private static ActionResult Fail(string message)
        {
            return new ActionResult { success = false, message = message ?? "Unknown error", path = "" };
        }
    }
}
